    package Management;

    import java.sql.*;
    import java.sql.Date;
    import java.util.ArrayList;
    import java.util.HashMap;

    public class Booking {
        public int bookingId;
        public int customerId;
        public int flightId;
        public int bags;
        public java.sql.Date bookingDate;
        public String bookingStatus;  
        public String chbStatus;      
        public String seatNumber;
        public ArrayList<Booking> bookings = new ArrayList<>();
        public ArrayList<Booking> filteredBookings = new ArrayList<>();
        double ticketPrice;
        int seatsAvailable ;
        public ArrayList<String> seats = new ArrayList<>();
        String seatClass ;
        public HashMap<String, String> seatDetails = new HashMap<>();
        public ArrayList<Flight1> flightsList = new ArrayList<>();

        public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }



        public void initiateBooking(int customerId, int flightId, java.sql.Date date, String bookingStatus, String chbStatus, String seatNumber) {
            String sql = "INSERT INTO Bookings (CustomerID, FlightID, BookingDate, BookingStatus, CHBStatus, SeatNumber, bags) VALUES (?, ?, ?, ?, ?, ?, 0)";
            try (Connection conn = connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, customerId);
                pstmt.setInt(2, flightId);
                pstmt.setDate(3, date);
                pstmt.setString(4, bookingStatus);
                pstmt.setString(5, chbStatus);
                pstmt.setString(6, seatNumber);
                pstmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    public int loadFlight(int customerId) {
    String query = "SELECT f.* FROM flights f " +
                   "WHERE f.status = 'Scheduled' AND NOT EXISTS (" +
                   "SELECT 1 FROM Bookings b WHERE b.FlightID = f.flightid AND b.CustomerID = ?)";

    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(query)) {

        if (conn == null) {
            return 0;
        }

        pstmt.setInt(1, customerId);
        try (ResultSet rs = pstmt.executeQuery()) {
            flightsList.clear();
            while (rs.next()) {
                Flight1 flight = new Flight1();
                flight.flightid = rs.getInt("flightid");
                flight.airline = rs.getString("airline");
                flight.departureAirport = rs.getInt("departureairport");
                flight.arrivalAirport = rs.getInt("arrivalairport");
                flight.scheduledDepartureTime = rs.getDate("scheduleddeparturetime");
                flight.actualDepartureTime = rs.getDate("actualdeparturetime");
                flight.arrivalTime = rs.getDate("arrivaltime");
                flight.ticketPrice = rs.getDouble("ticketprice");
                flight.status = rs.getString("status");
                flight.departureTerminal = rs.getString("departureterminal");
                flight.arrivalTerminal = rs.getString("arrivalterminal");
                flightsList.add(flight);
            }
        }
        return 1;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}

          public int updateBooking(int bookingId, int newCustomerId, int newFlightId, String newSeatNumber, String newBookingStatus, String newCHBStatus, int newBags) {
            String sql = "UPDATE Bookings SET CustomerID = ?, FlightID = ?, SeatNumber = ?, BookingStatus = ?, CHBStatus = ?, bags = ? WHERE BookingID = ?";
            try (Connection conn = connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, newCustomerId);
                pstmt.setInt(2, newFlightId);
                pstmt.setString(3, newSeatNumber);
                pstmt.setString(4, newBookingStatus);
                pstmt.setString(5, newCHBStatus);
                pstmt.setInt(6, newBags);
                pstmt.setInt(7, bookingId);
                pstmt.executeUpdate();
                return 1;
            } catch (SQLException e) {
                e.printStackTrace();
                return 0;
            }
        }

        public int cancelBooking(int bookingId) {
            String sql = "UPDATE Bookings SET BookingStatus = 'Cancelled', CHBStatus = 'Cancelled' WHERE BookingID = ?";
            try (Connection conn = connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, bookingId);
                pstmt.executeUpdate();
                return 1;
            } catch (SQLException e) {
                e.printStackTrace();
                return 0;
            }
        }

         public int checkinBooking(int bookingId, int bags) {
            String sql = "UPDATE Bookings SET CHBStatus = 'Checked-in', bags = ? WHERE BookingID = ?";

            try (Connection conn = connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(2, bookingId);
                pstmt.setInt(1, bags);
                pstmt.executeUpdate();
                return 1;
            } catch (SQLException e) {
                e.printStackTrace();
                return 0;
            }
        }


          public int boardBooking(int bookingId) {
            String sql = "UPDATE Bookings SET CHBStatus = 'Boarded' WHERE BookingID = ?";
            try (Connection conn = connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, bookingId);
                pstmt.executeUpdate();
                return 1;
            } catch (SQLException e) {
                e.printStackTrace();
                return 0;
            }
        }


            public int viewBooking(int bookingId) {
            Connection conn = connect();
            if (conn == null) {
                System.out.println("Connection failed.");
                return 0;
            }
            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Bookings WHERE BookingID = ?");
                pstmt.setInt(1, bookingId);

                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    this.bookingId = rs.getInt("BookingID");
                    this.customerId = rs.getInt("CustomerID");
                    this.flightId = rs.getInt("FlightID");
                    this.bookingDate = rs.getDate("BookingDate");
                     this.bookingStatus = rs.getString("BookingStatus");
                    this.chbStatus = rs.getString("CHBStatus");
                    this.seatNumber = rs.getString("SeatNumber");
                    this.bags = rs.getInt("bags");
                } else {
                    System.out.println("Booking not found.");
                    return 0;
                }

                rs.close();
                pstmt.close();
                conn.close();
                return 1;
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }
        }

        public int loadBookings() {
            Connection conn = connect();
            if (conn == null) {
                return 0;
            }
            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Bookings");
                ResultSet rs = pstmt.executeQuery();
                bookings.clear();
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.bookingId = rs.getInt("BookingID");
                    booking.customerId = rs.getInt("CustomerID");
                    booking.flightId = rs.getInt("FlightID");
                    booking.bookingDate = rs.getDate("BookingDate");
                    booking.bookingStatus = rs.getString("BookingStatus");
                    booking.chbStatus = rs.getString("CHBStatus");
                    booking.seatNumber = rs.getString("SeatNumber");
                     booking.bags = rs.getInt("bags");
                    bookings.add(booking);
                }
                rs.close();
                pstmt.close();
                conn.close();
                return 1;
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }
        }

        public int searchBookings(Integer bookingId, Integer customerId, Integer flightId, 
                              Date startDate, Date endDate, String bookingStatus, String chbStatus, String seatNumber, String seatClass) {
        Connection conn = connect();
        if (conn == null) {
            System.out.println("Connection failed.");
            return 0;
        }
            filteredBookings.clear();
        StringBuilder sql = new StringBuilder("SELECT B.*, S.class FROM Bookings B ");
    sql.append("INNER JOIN seats S ON B.FlightID = S.flight_id AND B.SeatNumber = S.seat_number WHERE ");

        ArrayList<Object> parameters = new ArrayList<>();

        if (bookingId != null) {
            sql.append("BookingID = ? AND ");
            parameters.add(bookingId);
        }
        if (customerId != null) {
            sql.append("CustomerID = ? AND ");
            parameters.add(customerId);
        }
        if (flightId != null) {
            sql.append("FlightID = ? AND ");
            parameters.add(flightId);
        }
        if (startDate != null && endDate != null) {
            sql.append("BookingDate BETWEEN ? AND ? AND ");
            parameters.add(startDate);
            parameters.add(endDate);
        }
        if (bookingStatus != null && !bookingStatus.isEmpty()) {
            sql.append("BookingStatus = ? AND ");
            parameters.add(bookingStatus);
        }
        if (chbStatus != null && !chbStatus.isEmpty()) {
            sql.append("CHBStatus = ? AND ");
            parameters.add(chbStatus);
        }
        if (seatNumber != null && !seatNumber.isEmpty()) {
            sql.append("SeatNumber = ? AND ");
            parameters.add(seatNumber);
        }

        if (seatClass != null && !seatClass.isEmpty()) {
            sql.append("S.class = ? AND ");
            parameters.add(seatClass);
        }

        if (!parameters.isEmpty()) {
            sql.setLength(sql.length() - 5);
        } else {
            sql.setLength(sql.length() - 7); 
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());
            for (int i = 0; i < parameters.size(); i++) {
                pstmt.setObject(i + 1, parameters.get(i));
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Booking booking = new Booking();
                booking.bookingId = rs.getInt("BookingID");
                booking.customerId = rs.getInt("CustomerID");
                booking.flightId = rs.getInt("FlightID");
                booking.bookingDate = rs.getDate("BookingDate");
                booking.bookingStatus = rs.getString("BookingStatus");
                booking.chbStatus = rs.getString("CHBStatus");
                booking.seatNumber = rs.getString("SeatNumber");
                booking.seatClass = rs.getString("class"); 
                filteredBookings.add(booking);
            }
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

          public void getFlightInfo(int flightId, String seatNumber) {
            Connection conn = connect();
            if (conn == null) {
                System.out.println("Connection failed.");
                return;
            }

            String query = "SELECT f.ticketprice AS TicketPrice, f.seatsAvailable AS SeatsAvailable, s.class AS SeatClass " +
                    "FROM flights f " +
                    "INNER JOIN seats s ON f.flightid = s.flight_id " +
                    "WHERE f.flightid = ? AND s.seat_number = ?";

            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, flightId);
                pstmt.setString(2, seatNumber);

                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    this.ticketPrice = rs.getDouble("TicketPrice");
                    this.seatsAvailable = rs.getInt("SeatsAvailable");
                    this.seatClass = rs.getString("SeatClass");

                    System.out.println("Flight ID: " + flightId);
                    System.out.println("Seat Number: " + seatNumber);
                    System.out.println("Ticket Price: $" + ticketPrice);
                    System.out.println("Seats Available: " + seatsAvailable);
                    System.out.println("Seat Class: " + seatClass);
                } else {
                    System.out.println("Flight or seat not found.");
                }

                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    public void loadSeats(int flightId) {
        Connection conn = connect();
        if (conn == null) {
            System.out.println("Connection failed.");
            return;
        }

        String query = "SELECT s.seat_number, s.class " +
                       "FROM seats s " +
                       "LEFT JOIN Bookings b ON s.flight_id = b.FlightID AND s.seat_number = b.SeatNumber AND b.BookingStatus != 'Cancelled' " +
                       "WHERE s.flight_id = ? AND (b.BookingID IS NULL OR b.BookingStatus = 'Cancelled')";

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, flightId);

            ResultSet rs = pstmt.executeQuery();

            seats.clear(); 

            while (rs.next()) {
                String seatNumber = rs.getString("seat_number");
                String seatClass = rs.getString("class");
                seats.add(seatNumber);
                seatDetails.put(seatNumber, seatClass);
            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public String getSeatClass(int flightId, String seatNumber) {

            if (seatDetails.containsKey(seatNumber)) {
                return seatDetails.get(seatNumber);
            }

            Connection conn = connect();
            if (conn == null) {
                System.out.println("Connection failed.");
                return "";
            }

            String query = "SELECT class FROM seats WHERE flight_id = ? AND seat_number = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, flightId);
                pstmt.setString(2, seatNumber);

                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    return rs.getString("class");
                }

                rs.close();
                return "";
            } catch (SQLException e) {
                e.printStackTrace();
                return "";
            } finally {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

     public double getTicketPriceForSeat(int flightId, String seatNumber) {
        String sql = "SELECT f.ticketprice, s.class FROM flights f "
                   + "INNER JOIN seats s ON f.flightid = s.flight_id "
                   + "WHERE f.flightid = ? AND s.seat_number = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, flightId);
            pstmt.setString(2, seatNumber);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double basePrice = rs.getDouble("ticketprice");
                String seatClass = rs.getString("class");

                switch (seatClass) {
                    case "Business":
                        return basePrice * 2; 
                    case "First":
                        return basePrice * 4; 
                    default:
                        return basePrice; 
                }
            } else {
                System.out.println("Seat not found or flight for the seat not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0; 
    }



       public static void main(String[] args) {
    Booking bookingManager = new Booking();

    // Example customer ID for testing
    int testCustomerId = 1008; // Replace with a valid customer ID

    // Call loadFlight method
    int loadResult = bookingManager.loadFlight(testCustomerId);

    // Check the result and print the loaded flights
    if (loadResult == 1 && !bookingManager.flightsList.isEmpty()) {
        System.out.println("Loaded Flights for Customer ID " + testCustomerId + ":");
        for (Flight1 flight : bookingManager.flightsList) {
            System.out.println("Flight ID: " + flight.flightid + ", Airline: " + flight.airline);
            // Add more flight details here as needed
        }
    } else {
        System.out.println("No flights found or an error occurred.");
    }

    // Rest of your test code...
}


    }
