package Management;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
import java.sql.*;
import java.util.*;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public class Airport {
    public int airportId;
    public String name;
    public String country; 
    public String city;
    public int postalCode;
    public java.sql.Date dateEstablished;
    public String airportWebsite;
    public ArrayList<String> countryList = new ArrayList<>(); 
    public ArrayList<String> cityList = new ArrayList<>();
    public ArrayList<Integer> postalList = new ArrayList<>();
    public ArrayList<Airport> filteredAirports = new ArrayList<>();
    public ArrayList<Airport> airportList = new ArrayList<>();
    public ArrayList<Airport> airportwithairport = new ArrayList<>();
    public ArrayList<String> badTable = new ArrayList<>();
    public Airport (){
        
    }
public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }


public int createAirport(String name, String cityName, int postalCode, java.sql.Date dateEstablished, String airportWebsite) {
    String sqlFindCityAndPostal = "SELECT city_id FROM Cities WHERE city_name = ?";
    String sqlFindPostalCode = "SELECT postalcode FROM PostalCodes WHERE postal_code = ?";
    
    try (Connection conn = connect()) {
        conn.setAutoCommit(false);
        try (PreparedStatement pstmtCity = conn.prepareStatement(sqlFindCityAndPostal)) {
            pstmtCity.setString(1, cityName);
            ResultSet rsCity = pstmtCity.executeQuery();
            if (rsCity.next()) {
                int cityId = rsCity.getInt("city_id");

                try (PreparedStatement pstmtPostal = conn.prepareStatement(sqlFindPostalCode)) {
                    pstmtPostal.setInt(1, postalCode);
                    ResultSet rsPostal = pstmtPostal.executeQuery();
                    if (rsPostal.next()) {
                        int postalId = rsPostal.getInt("postalcode");
   
                        String sqlInsertAirport = "INSERT INTO airports (name, city_id, postalcode, date_established, airport_website) VALUES (?, ?, ?, ?, ?)";
                        try (PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsertAirport, Statement.RETURN_GENERATED_KEYS)) {
                            pstmtInsert.setString(1, name);
                            pstmtInsert.setInt(2, cityId);
                            pstmtInsert.setInt(3, postalId);
                            pstmtInsert.setDate(4, dateEstablished);
                            pstmtInsert.setString(5, airportWebsite);
                            pstmtInsert.executeUpdate();

                            ResultSet rs = pstmtInsert.getGeneratedKeys();
                            if (rs.next()) {
                                conn.commit();
                                return rs.getInt(1); 
                            } else {
                                conn.rollback();
                                return 0; 
                            }
                        }
                    } else {
                        conn.rollback();
                        System.out.println("Postal code not found.");
                        return 0;
                    }
                }
            } else {
                conn.rollback();
                System.out.println("City not found.");
                return 0;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}



public int updateAirportDetails(int airportId, String newName, String newCityName, Integer newPostalCode, java.sql.Date dateEstablished, String airportWebsite) {
    String sql = "UPDATE airports " +
                 "SET " +
                 "    name = ?, " +
                 "    city_id = (SELECT city_id FROM Cities WHERE city_name = ?), " +
                 "    postalcode = (SELECT postalcode FROM PostalCodes WHERE postal_code = ?), " +
                 "    date_established = ?, " +
                 "    airport_website = ? " +
                 "WHERE " +
                 "    airportid = ?";
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, newName);
        pstmt.setString(2, newCityName);
        pstmt.setInt(3, newPostalCode); // Assuming newPostalCode is the actual postal code
        pstmt.setDate(4, dateEstablished);
        pstmt.setString(5, airportWebsite);
        pstmt.setInt(6, airportId);

        int affectedRows = pstmt.executeUpdate();
        if (affectedRows > 0) {
            return 1; // Successfully updated
        } else {
            return 0; // No rows updated, possibly invalid airportId
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}



private boolean isPostalCodeValid(Integer postalCode) {
    String sql = "SELECT COUNT(*) FROM PostalCodes WHERE postal_code = ?";
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, postalCode);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false; 
}

    public int removeAirport(int airportId) {
        String sql = "DELETE FROM airports WHERE airportid = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, airportId);
            pstmt.executeUpdate();
            return 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

public int lookThruAirports(int searchAirportId) {
    String sqlFindForeignKeyTables = "SELECT DISTINCT kcu.table_name, kcu.column_name " +
        "FROM information_schema.table_constraints AS tc " +
        "JOIN information_schema.key_column_usage AS kcu " +
        "ON tc.constraint_name = kcu.constraint_name " +
        "WHERE tc.constraint_type = 'FOREIGN KEY' " +
        "AND tc.table_schema = 'hello' " + 
        "AND kcu.referenced_table_name = 'airports' " +
        "AND kcu.referenced_table_schema = 'hello' " +
        "AND kcu.referenced_column_name = 'airportid'";
    Connection conn = connect();
    if (conn == null) {
        System.out.println("Connection failed.");
        return 0;
    }
    airportwithairport.clear();
    badTable.clear(); 
    try (PreparedStatement pstmtFindForeignKeyTables = conn.prepareStatement(sqlFindForeignKeyTables);
         ResultSet rsForeignKeyTables = pstmtFindForeignKeyTables.executeQuery()) {
        while (rsForeignKeyTables.next()) {
            String tableName = rsForeignKeyTables.getString("table_name");
            String columnName = rsForeignKeyTables.getString("column_name");

            if (tableName.equalsIgnoreCase("airports")) {
                continue;
            }
            String sqlSearch = "SELECT COUNT(*) FROM " + tableName + " WHERE " + columnName + " = ?";
            try (PreparedStatement pstmtSearch = conn.prepareStatement(sqlSearch)) {
                pstmtSearch.setInt(1, searchAirportId);
                ResultSet rsSearch = pstmtSearch.executeQuery();
                if (rsSearch.next() && rsSearch.getInt(1) > 0) {
                    if (!badTable.contains(tableName)) {
                        badTable.add(tableName);
                    }
                }
            } catch (SQLException e) {
                System.out.println("Error querying table " + tableName + ": " + e.getMessage());
            }
        }
        return 1;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}


  public int loadAddress() {
        Connection conn = connect();
        if (conn == null) {
            System.out.println("Connection failed.");
            return 0;
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT country_name FROM Countries");
            ResultSet rs = pstmt.executeQuery();
            countryList.clear();
            while (rs.next()) {
                countryList.add(rs.getString("country_name"));
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT city_name FROM Cities");
            ResultSet rs = pstmt.executeQuery();
            cityList.clear();
            while (rs.next()) {
                cityList.add(rs.getString("city_name"));
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT postal_code FROM PostalCodes");
            ResultSet rs = pstmt.executeQuery();
            postalList.clear();
            while (rs.next()) {
                postalList.add(rs.getInt("postal_code"));
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }

        try {
            conn.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return 1;
    }

public ArrayList<String> getCitiesForCountry(String selectedCountry) {
    ArrayList<String> cities = new ArrayList<>();
    String sql = "SELECT c.city_name FROM Cities c " +
                 "JOIN Countries co ON c.country_id = co.country_id " +
                 "LEFT JOIN airports a ON c.city_id = a.city_id " +
                 "WHERE co.country_name = ? AND a.city_id IS NULL";

    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, selectedCountry);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            cities.add(rs.getString("city_name"));
        }
    } catch (SQLException e) {
        System.out.println("Database error: " + e.getMessage());
    }

    return cities;
}


public ArrayList<Integer> getPostalCodesForCity(String selectedCity) {
    ArrayList<Integer> postalCodes = new ArrayList<>();
    String sql = "SELECT DISTINCT pc.postal_code FROM PostalCodes pc "
               + "JOIN Cities c ON pc.city_id = c.city_id "
               + "WHERE c.city_name = ?";

    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, selectedCity);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            postalCodes.add(rs.getInt("postal_code"));
        }
    } catch (SQLException e) {
        System.out.println("Database error: " + e.getMessage());
    }

    return postalCodes;
}



  public int loadAirports() {
    Connection conn = connect();
    if (conn == null) {
        return 0;
    }
    try {
        PreparedStatement pstmt = conn.prepareStatement(
            "SELECT a.airportid, a.name, c.city_name, co.country_name, a.postalcode, a.date_established, a.airport_website \n" +
            "FROM airports a " +
            "JOIN PostalCodes pc ON a.postalcode = pc.postalcode " +
            "JOIN Cities c ON pc.city_id = c.city_id " +
            "JOIN Countries co ON c.country_id = co.country_id"
        );
        ResultSet rs = pstmt.executeQuery();
        airportList.clear();
        while (rs.next()) {
            Airport airport = new Airport();
            airport.airportId = rs.getInt("airportid");
            airport.name = rs.getString("name");
            airport.country = rs.getString("country_name");
            airport.city = rs.getString("city_name");
            airport.postalCode = rs.getInt("postalcode");  
            airport.dateEstablished = rs.getDate("date_established");
            airport.airportWebsite = rs.getString("airport_website");
            airportList.add(airport);
        }
        rs.close();
        pstmt.close();
        conn.close();
        return 1;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0;
    }
}

public int viewAirport(int airportId) {
    Connection conn = connect();
    if (conn == null) {
        System.out.println("Connection failed.");
        return 0;
    }
    try {
        String sql = "SELECT a.airportid, a.name, c.city_name, co.country_name, pc.postal_code, a.date_established, a.airport_website " + // Changed to pc.postal_code
                "FROM airports a " +
                "JOIN PostalCodes pc ON a.postalcode = pc.postalcode " + // Ensure correct join condition
                "JOIN Cities c ON pc.city_id = c.city_id " +
                "JOIN Countries co ON c.country_id = co.country_id " +
                "WHERE a.airportid = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, airportId);

        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            this.airportId = rs.getInt("airportid");
            this.country = rs.getString("country_name");
            this.city = rs.getString("city_name");
            this.name = rs.getString("name"); 
            this.dateEstablished = rs.getDate("date_established"); 
            this.airportWebsite = rs.getString("airport_website"); 
            this.postalCode = rs.getInt("postal_code"); // Changed to retrieve postal_code
        } else {
            System.out.println("Airport not found.");
            return 0;
        }

        rs.close();
        pstmt.close();
        conn.close();
        return 1;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0;
    }
}


public int searchAirports(Integer airportId, String name, String country, String city, Integer postalCode, String sortBy, java.sql.Date fromYear, java.sql.Date toYear, java.sql.Date dateEstab, String sortOrder) {
    Connection conn = connect();
    if (conn == null) {
        System.out.println("Connection failed.");
        return 0;
    }
    filteredAirports.clear();
    StringBuilder sql = new StringBuilder(
        "SELECT a.airportid, a.name, c.city_name, co.country_name, a.postalcode, a.date_established, a.airport_website " +
        "FROM airports a " +
        "JOIN PostalCodes pc ON a.postalcode = pc.postalcode " +
        "JOIN Cities c ON pc.city_id = c.city_id " +
        "JOIN Countries co ON c.country_id = co.country_id WHERE 1=1"
    );
    ArrayList<Object> parameters = new ArrayList<>();
    
    if (airportId != null) {
        sql.append(" AND a.airportid = ?");
        parameters.add(airportId);
    }
    if (name != null && !name.isEmpty()) {
        sql.append(" AND a.name LIKE ?");
        parameters.add("%" + name + "%");
    }
    if (postalCode != null && postalCode != 0) {
        sql.append(" AND a.postalcode = ?");
        parameters.add(postalCode);
    }
    if (country != null && !country.isEmpty()) {
        sql.append(" AND co.country_name = ?");
        parameters.add(country);
    }
    if (city != null && !city.isEmpty()) {
        sql.append(" AND c.city_name = ?");
        parameters.add(city);
    }
      if (dateEstab != null) {
        sql.append(" AND a.date_established = ?");
        parameters.add(dateEstab);
    }
    if (fromYear != null) {
        sql.append(" AND a.date_established >= ?");
        parameters.add(fromYear);
    }
    if (toYear != null) {
        sql.append(" AND a.date_established <= ?");
        parameters.add(toYear);
    }

    if (sortBy != null && !sortBy.isEmpty() && (sortOrder.equalsIgnoreCase("ASC") || sortOrder.equalsIgnoreCase("DESC"))) {
        sql.append(" ORDER BY ").append(sortBy).append(" ").append(sortOrder);
    }

    try {
        PreparedStatement pstmt = conn.prepareStatement(sql.toString());
        for (int i = 0; i < parameters.size(); i++) {
            pstmt.setObject(i + 1, parameters.get(i));
        }
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Airport airport = new Airport();
            airport.airportId = rs.getInt("airportid");
            airport.name = rs.getString("name");
            airport.country = rs.getString("country_name");
            airport.city = rs.getString("city_name");
            airport.postalCode = rs.getInt("postalcode");
            airport.dateEstablished = rs.getDate("date_established");
            airport.airportWebsite = rs.getString("airport_website");
            filteredAirports.add(airport);
        }
        rs.close();
        pstmt.close();
        conn.close();
        return 1;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0;
    }
}

public int getAirportIdByName(String airportName) {
    String sql = "SELECT airportid FROM airports WHERE name = ?";
 
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, airportName);
        
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("airportid");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}

public static void main(String[] args) {
    try {
        // Initialize Airport manager
        Airport airportManager = new Airport();

        // Sample airport details to update
        int airportIdToUpdate = 5;  // Replace with the actual airport ID you want to update
        String newName = "Heathrow Airport";
        String newCityName = "Tokyo";
        int newPostalCode = 1000001;
        java.sql.Date newDateEstablished = java.sql.Date.valueOf("2023-01-01");
        String newAirportWebsite = "https://example.com";

        // Execute the update
        int result = airportManager.updateAirportDetails(airportIdToUpdate, newName, newCityName, newPostalCode, newDateEstablished, newAirportWebsite);

        if (result == 1) {
            System.out.println("Airport details updated successfully.");
        } else {
            System.out.println("Failed to update airport details.");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}




}