package Management;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ccslearner
 */
public class Staff {
    
    public enum Performance {
        EXCELLENT, GREAT, GOOD, NEEDSWORK
    }
    public enum Sex{
        FEMALE, MALE
    }
     
    // staff info
    public int staffid;
    public String firstname;
    public String lastname;
    public String middlename;
    public Long contactnumber;
    public Date dateofbirth;
    public Sex sex;
    //staff address
    public String country;
    public String cityMunicipality;
    public int postalcode;
    // staff professional
    public String job;
    public double salary;
    public Performance performance;
    public String emrgencycontactperson;
    public Long emrgencyphone;
    public int flightid; // for shifts
    public List<Staff> staffList = new ArrayList<>();
    public List<String> cityList = new ArrayList<>();
    public List<String> countryList = new ArrayList<>();
    public List<Integer> postalList = new ArrayList<>();


    public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }


 
    public int loadStaffMembers(
            String sort,
            String searchId,
            String searchFirstName,
            String searchMiddleName,
            String searchLastName,
            Long searchPhone,
            Date birthdate,
            String sex,
            String country,
            String cityMunicipality,
            int zipcode,
            String job,
            Double salary,
            String performance) {
        Connection conn = connect();

        if (conn == null) {
            return 0; // Connection failed
        }

        System.out.println("\n\nsearchId: " + searchId);
        System.out.println("searchFirstName: " + searchFirstName);
        System.out.println("searchMiddleName: " + searchMiddleName);
        System.out.println("searchLastName: " + searchLastName);
        System.out.println("searchPhone: " + searchPhone);
        System.out.println("country: " + country);
        System.out.println("cityMunicipality: " + cityMunicipality);
        System.out.println("zipcode: " + zipcode);
        System.out.println("job: " + job);
        System.out.println("salary: " + salary);
        System.out.println("performance: " + performance);
        
        try {
            StringBuilder query = new StringBuilder("SELECT s.*, p.postal_code, ci.city_name, co.country_name " +
                    "FROM airlinestaffrecords s " +
                    "LEFT JOIN PostalCodes p ON s.postalcode_id = p.postalcode " +
                    "LEFT JOIN Cities ci ON p.city_id = ci.city_id " +
                    "LEFT JOIN Countries co ON ci.country_id = co.country_id");
            
            query.append(" WHERE 1=1");

            // Add conditions for searching by specific attributes
            if (searchId != null && !searchId.isEmpty()) {
                appendWhereClause(query, "staffid = ?");
            }

            // Add conditions for searching by first name, middle name, and last name
            if (searchFirstName != null && !searchFirstName.isEmpty()) {
                appendWhereClause(query, "s.firstname LIKE ?");
            }

            if (searchMiddleName != null && !searchMiddleName.isEmpty()) {
                appendWhereClause(query, "s.middlename LIKE ?");
            }

            if (searchLastName != null && !searchLastName.isEmpty()) {
                appendWhereClause(query, "s.lastname LIKE ?");
            }

            if (searchPhone != null && searchPhone > 0) {
                appendWhereClause(query, "s.contactnumber = ?");
            }
            
            if (birthdate != null) {
                appendWhereClause(query, "s.dateofbirth = ?");
            }
            
            if (sex != null && !sex.isEmpty()) {
                appendWhereClause(query, "s.sex LIKE ?");
            }

            if (country != null && !country.isEmpty()) {
                appendWhereClause(query, "co.country_name LIKE ?");
            }

            if (cityMunicipality != null && !cityMunicipality.isEmpty()) {
                appendWhereClause(query, "ci.city_name LIKE ?");
            }

            if (zipcode > 0) {
                appendWhereClause(query, "p.postal_code LIKE ?");
            }

            if (job != null && !job.isEmpty()) {
                appendWhereClause(query, "s.job LIKE ?");
            }

            if (salary != null) {
                appendWhereClause(query, "s.salary = ?");
            }

            if (performance != null && !performance.isEmpty()) {
                appendWhereClause(query, "s.performance = ?");
            }

            // Check the value of the 'sort' parameter and modify the query accordingly
            if (sort != null && !sort.isEmpty()) {
                appendOrderByClause(query, sort);
            }

            PreparedStatement pstmt = conn.prepareStatement(query.toString());

            int pIndex = 1;

            if (searchId != null && !searchId.isEmpty()) {
                pstmt.setInt(pIndex++, Integer.parseInt(searchId));
            }

            if (searchFirstName != null && !searchFirstName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchFirstName + "%");
            }

            if (searchMiddleName != null && !searchMiddleName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchMiddleName + "%");
            }

            if (searchLastName != null && !searchLastName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchLastName + "%");
            }

            if (searchPhone != null && searchPhone > 0) {
                pstmt.setLong(pIndex++, searchPhone);
            }
            
            if (birthdate != null) {
                pstmt.setDate(pIndex++, birthdate);
            }
            
            if (sex != null && !sex.isEmpty()) {
                pstmt.setString(pIndex++, sex);
            }


            if (country != null && !country.isEmpty()) {
                pstmt.setString(pIndex++, "%" + country + "%");
            }

            if (cityMunicipality != null && !cityMunicipality.isEmpty()) {
                pstmt.setString(pIndex++, "%" + cityMunicipality + "%");
            }

            if (zipcode > 0) {
                pstmt.setInt(pIndex++, zipcode);
            }

            if (job != null && !job.isEmpty()) {
                pstmt.setString(pIndex++, "%" + job + "%");
            }

            if (salary != null) {
                pstmt.setDouble(pIndex++, salary);
            }
            
            if (performance != null && !performance.isEmpty()) {
                String perf = performance.toString();
                if ("NEEDSWORK".equals(perf)) {
                    perf = "NEEDS WORK";
                }
                pstmt.setString(pIndex++, perf);
            }
            
            System.out.println("Final SQL Query: " + query.toString());

            ResultSet rs = pstmt.executeQuery();

            staffList.clear();
            while (rs.next()) {
                Staff staff = new Staff();
                staff.staffid = rs.getInt("staffid");
                staff.firstname = rs.getString("firstname");
                staff.lastname = rs.getString("lastname");
                staff.middlename = rs.getString("middlename");
                staff.contactnumber = rs.getLong("contactnumber");
                staff.dateofbirth = rs.getDate("dateofbirth");
                staff.sex = Sex.valueOf(rs.getString("sex").toUpperCase());
                staff.country = rs.getString("country_name");
                staff.cityMunicipality = rs.getString("city_name");
                staff.postalcode = rs.getInt("postal_code");
                staff.job = rs.getString("job");
                staff.salary = rs.getDouble("salary");
                staff.performance = Performance.valueOf(rs.getString("performance").replace(" ", "").toUpperCase());
                staff.emrgencycontactperson = rs.getString("emrgencycontactperson");
                staff.emrgencyphone = rs.getLong("emrgencyphone");
                staff.flightid = rs.getInt("flightid"); // note: take care to allow multiple flight ids
                staffList.add(staff);
            }

            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println("ERROR!!!" + e.getMessage());
            return 0;
        }
    }
    
    
    // Helper methods for building queries

    private void appendWhereClause(StringBuilder query, String condition) {
        query.append(" AND ").append(condition);
    }

    private void appendOrderByClause(StringBuilder query, String sort) {
        switch (sort) {
            case "az":
                query.append(" ORDER BY lastname ASC, firstname ASC, middlename ASC");
                break;
            case "za":
                query.append(" ORDER BY lastname DESC, firstname DESC, middlename DESC");
                break;
            case "birthdate":
                query.append(" ORDER BY dateofbirth ASC");
                break;
            case "address":
                query.append(" ORDER BY cityMunicipality ASC, province ASC, barangay ASC, streetName ASC");
                break;
                
            case "job":
                query.append(" ORDER BY job ASC");
                break;
            
            case "salary asc":
                query.append(" ORDER BY salary ASC");
                break;
                
            case "salary desc":
                query.append(" ORDER BY salary DESC");
                break;
              
        }
    }

     
    public int loadStaff(int staffid) {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement(
                "SELECT s.*, co.country_name, ci.city_name, pc.postal_code " +
                "FROM airlinestaffrecords s " +
                "JOIN PostalCodes pc ON s.postalcode_id = pc.postalcode " +
                "JOIN Cities ci ON pc.city_id = ci.city_id " +
                "JOIN Countries co ON ci.country_id = co.country_id " +
                "WHERE s.staffid = ?");
            pstmt.setInt(1, staffid);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                this.staffid = rs.getInt("staffid");
                this.firstname = rs.getString("firstname");
                this.lastname = rs.getString("lastname");
                this.middlename = rs.getString("middlename");
                this.contactnumber = rs.getLong("contactnumber");
                this.dateofbirth = rs.getDate("dateofbirth");
                this.sex = Sex.valueOf(rs.getString("sex").toUpperCase());
                
                this.job = rs.getString("job");
                this.salary = rs.getDouble("salary");
                this.performance = Performance.valueOf(rs.getString("performance").toUpperCase());
                this.emrgencycontactperson= rs.getString("emrgencycontactperson");
                this.emrgencyphone = rs.getLong("emrgencyphone");
                this.flightid = rs.getInt("flightid"); 
               
                this.country = rs.getString("country_name");
                this.cityMunicipality = rs.getString("city_name");
                this.postalcode = rs.getInt("postal_code");
               
                
                          
            }


            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Failure
        }
    }

    public int createStaff(
       
        String firstname, //1
        String lastname,//2
        String middlename,//3
        Long contactnumber,//4
        Date dateofbirth,//5
        Sex sex,//6
        String cityMunicipality,
        int postalcode_id,//7
        String job,//8
        double salary,//9
        Performance performance,//10
        String emrgencycontactperson,//11
        Long emrgencyphone,//12
        int flightid //13
        // for shifts
        ) {
        
        // test if staff exists
        int ifExistingId = (staffExists(firstname, middlename,
                lastname, dateofbirth));
        if (ifExistingId != -1) {
            return ifExistingId;
        }

        // Get city_id based on cityMunicipality
        int cityId = getCityId(cityMunicipality);

        // Get postalcode_id based on zipcode and city_id
        int postalCodeId = getPostalCodeId(postalcode_id, cityId);
        
        String sql = "INSERT INTO airlinestaffrecords (staffid, firstname, " +
        "lastname, middlename, contactnumber, dateofbirth, sex, "+
         "postalcode_id, job, salary, performance, emrgencycontactperson,"
                + " emrgencyphone, flightid)" +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


        String qry = "SELECT MAX(staffid) + 1 AS newID FROM airlinestaffrecords";
        int staffid = 1;

        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                staffid = rs.getInt("newID");
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }
        
        String perf = performance.name();
        if (performance.name() == "NEEDSWORK"){
            perf = "NEEDS WORK";
        }

        try (Connection conn = connect();
            PreparedStatement pstmtStaff = conn.prepareStatement(sql)) {
            pstmtStaff.setInt(1, staffid);
            pstmtStaff.setString(2, firstname);
            pstmtStaff.setString(3, lastname);
            pstmtStaff.setString(4, middlename);
            pstmtStaff.setLong(5, contactnumber);
            pstmtStaff.setDate(6, dateofbirth);
            pstmtStaff.setString(7, sex.name());

            pstmtStaff.setInt(8, postalCodeId);

            pstmtStaff.setString(9, job);
            pstmtStaff.setDouble(10, salary);
            pstmtStaff.setString(11, perf);
            pstmtStaff.setString(12, emrgencycontactperson);
            pstmtStaff.setLong(13, emrgencyphone);
            pstmtStaff.setInt(14, flightid);
            
            pstmtStaff.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Query: " + sql);
            System.out.println("Failed: " + e.getMessage());
            return 0;
        }

        return 1;
    }

    
    public int updateStaff(
        int staffid,
        String completename_First,
        String completename_Last,
        String completename_Middle,
        Long mobile,
        String country,  
        String cityMunicipality,
        int zipcode,
        Date dateOfBirth,
        Sex sex,
        String job,
        double salary,//15
        Performance performance,
        String emrgencycontactperson,//17
        long emrgencyphone,
        int flightid
        ) {//19
        String sql = "UPDATE airlinestaffrecords SET " +
        "firstname = ?, " +
        "lastname = ?, " +
        "middlename = ?, " +
        "contactnumber = ?, " +
        "dateofbirth = ?, " + 
        "sex = ?, " +
        "postalcode_id = ?, " +
        "job = ?, " +
        "salary = ?, " +
        "performance = ?, " +
        "emrgencycontactperson = ?, " +
        "emrgencyphone = ?, " + // Added comma here
        "flightid = ? " + // Added space before WHERE
        "WHERE staffid = ?";
        
        // Get city_id based on cityMunicipality
        int cityId = getCityId(cityMunicipality);

        // Get postalcode_id based on zipcode and city_id
        int postalCodeId = getPostalCodeId(zipcode, cityId);

        try (Connection conn = connect();
            PreparedStatement pstmtStaff = conn.prepareStatement(sql)) {
                pstmtStaff.setString(1, completename_First);
                pstmtStaff.setString(2, completename_Last);
                pstmtStaff.setString(3, completename_Middle);
                pstmtStaff.setLong(4, mobile);
                pstmtStaff.setDate(5, dateOfBirth);
                pstmtStaff.setString(6, sex.name());
                
                pstmtStaff.setInt(7, postalCodeId);

                pstmtStaff.setString(8, job);
                pstmtStaff.setDouble(9, salary);
                pstmtStaff.setString(10, performance.name());
                pstmtStaff.setString(11, emrgencycontactperson);
                pstmtStaff.setLong(12, emrgencyphone);
                pstmtStaff.setInt(13, flightid);
                pstmtStaff.setInt(14, staffid);
           
            
            pstmtStaff.executeUpdate();

            
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed: " + e.getMessage());
            return 0; // Error occurred
        }
        
        return 1;
    }
    
   public int deleteStaff(int staffId) {
     try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM airlinestaffrecords WHERE staffid=?");
             pstmt.setInt(1, staffId);
             
             int rowsAffected = pstmt.executeUpdate();
             
             pstmt.close();
             conn.close();
             
            return rowsAffected;
     }catch(Exception e){
         return 0;
     }
     
   
}
   
       public int loadAddress() {
            Connection conn = connect();
            if (conn == null) {
                System.out.println("Connection failed.");
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT country_name FROM Countries");
                ResultSet rs = pstmt.executeQuery();
                countryList.clear();
                while (rs.next()) {
                    countryList.add(rs.getString("country_name"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT city_name FROM Cities");
                ResultSet rs = pstmt.executeQuery();
                cityList.clear();
                while (rs.next()) {
                    cityList.add(rs.getString("city_name"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT postal_code FROM PostalCodes");
                ResultSet rs = pstmt.executeQuery();
                postalList.clear();
                while (rs.next()) {
                    postalList.add(rs.getInt("postal_code"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            return 1;
        }

    public ArrayList<String> getCitiesForCountry(String selectedCountry) {
        ArrayList<String> cities = new ArrayList<>();
        // SQL query to select cities in the specified country based on the includeUsedCities flag
        String sql;
        sql = "SELECT c.city_name FROM Cities c " +
              "JOIN Countries co ON c.country_id = co.country_id " +
              "WHERE co.country_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, selectedCountry);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                cities.add(rs.getString("city_name"));
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }

        return cities;
    }



    public ArrayList<Integer> getPostalCodesForCity(String selectedCity) {
        ArrayList<Integer> postalCodes = new ArrayList<>();
        String sql = "SELECT DISTINCT pc.postal_code FROM PostalCodes pc "
                   + "JOIN Cities c ON pc.city_id = c.city_id "
                   + "WHERE c.city_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, selectedCity);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                postalCodes.add(rs.getInt("postal_code"));
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }

        return postalCodes;
    }
    
    private int getCityId(String cityMunicipality) {
        String sql = "SELECT city_id FROM Cities WHERE city_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cityMunicipality);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("city_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // City not found
    }

    private int getPostalCodeId(int zipcode, int cityId) {
        String sql = "SELECT postalcode FROM PostalCodes WHERE postal_code = ? AND city_id = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, zipcode);
            pstmt.setInt(2, cityId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("postalcode");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Postal code not found
    }

    private int staffExists(
        String firstname,
        String middlename,
        String lastname,
        Date dateOfBirth) {

        String sql = "SELECT staffid FROM airlinestaffrecords " +
                "WHERE firstname = ? " +
                "AND lastname = ? " +
                "AND COALESCE(middlename, '') = COALESCE(?, '') " +
                "AND dateofbirth = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, firstname);
            pstmt.setString(2, lastname);
            pstmt.setString(3, middlename);
            pstmt.setDate(4, dateOfBirth);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                return rs.getInt("staffid"); // returns this if exists
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // returns this if doesn't exist
    }
    
    public List<Staff> getStaffList() {
        return staffList;
    }
    
    public static void main(String[] args) {
        Staff staffManager =  new Staff();
        
        int staffid = 1;
        String completename_First = "LOL";
        String completename_Last = "LOL";
        String completename_Middle = "M";
        Long mobile = 12345678L;
        String country = "Philippines";
        String cityMunicipality = "Manila";
        int zipcode = 1;
        Date dateOfBirth = java.sql.Date.valueOf("1990-01-01");
        Staff.Sex sex = Staff.Sex.MALE;
        String job = "Software Engineer";
        double salary = 50000.0;
        Staff.Performance performance = Staff.Performance.EXCELLENT;
        String emrgencycontactperson = "Emergency Contact Name";
        long emrgencyphone = 9876543210L;
        int flightid = 1;

        // Call the updateStaff method
        staffManager.updateStaff(
            staffid,
            completename_First,
            completename_Last,
            completename_Middle,
            mobile,
            country,
            cityMunicipality,
            zipcode,
            dateOfBirth,
            sex,
            job,
            salary,
            performance,
            emrgencycontactperson,
            emrgencyphone,
            flightid
        );

    }
    
    
    public int getStaffId() {
        return staffid;
    }

    public String getFirstname() {
        return firstname;
    }
    public String getLastname() {
        return lastname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public long getContactnumber() {
        return contactnumber;
    }

    public Date getDateOfBirth() {
        return dateofbirth;
    }

    public Sex getSex() {
        return sex;
    }
   
    public String getCountry() {
        return country;
    }

    public String getCityMunicipality() {
        return cityMunicipality;
    }

    public int getPostal() {
        return postalcode;
    }

    public String getJob() {
        return job;
    }

    public double getSalary() {
        return salary;
    }

    public Performance getPerformance() {
        return performance;
    }

    public String getEmrgencycontactperson() {
        return emrgencycontactperson;
    }

    public long getEmrgencyphone() {
        return emrgencyphone;
    }

    public int getFlightid() {
        return flightid;
    }

}