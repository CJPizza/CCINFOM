/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Management;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author ccslearner
 */
public class Customer {
    
    public enum Sex{
        FEMALE, MALE
    }
    
    public int customerId;
    public String completename_First;
    public String completename_Middle;
    public String completename_Last;
    public long mobile;
    public String cntry;
    public String citymunicipality;
    public int postalCode;
    public Date dateOfBirth;
    public Sex sex;
    public boolean specialNeeds;
    public List<Customer> customerList = new ArrayList<>();
    public List<String> cityList = new ArrayList<>();
    public List<String> countryList = new ArrayList<>();
    public List<Integer> postalList = new ArrayList<>();

    
    public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }


    
    public int loadCustomers(
            String sort, 
            String filterSpecialNeeds, 
            String searchFirstName,
            String searchMiddleName,
            String searchLastName,
            String customerId,
            Long phone,
            Date birthdate,
            String sex,
            String country,
            String city,
            int zip) {
        Connection conn = connect();
        if (conn == null) {
            return 0; // Connection failed
        }

        try {
            StringBuilder query = new StringBuilder("SELECT c.*, p.postal_code, ci.city_name, co.country_name " +
                    "FROM customers c " +
                    "LEFT JOIN PostalCodes p ON c.postalcode_id = p.postalcode " +
                    "LEFT JOIN Cities ci ON p.city_id = ci.city_id " +
                    "LEFT JOIN Countries co ON ci.country_id = co.country_id");

            // Add WHERE clause for filtering by special needs
            if ("Y".equals(filterSpecialNeeds)) {
                query.append(" WHERE c.specialneeds = true");
            }

            // Add conditions for searching by first name, middle name, and last name
            if (searchFirstName != null && !searchFirstName.isEmpty()) {
                appendWhereClause(query, "c.completename_First LIKE ?");
            }

            if (searchMiddleName != null && !searchMiddleName.isEmpty()) {
                appendWhereClause(query, "c.completename_Middle LIKE ?");
            }

            if (searchLastName != null && !searchLastName.isEmpty()) {
                appendWhereClause(query, "c.completename_Last LIKE ?");
            }

            // Add conditions for searching by additional parameters
            if (customerId != null && !customerId.isEmpty()) {
                appendWhereClause(query, "c.customerid = ?");
            }

            if (phone > 0) {
                appendWhereClause(query, "c.phone = ?");
            }

            if (birthdate != null) {
                appendWhereClause(query, "c.dateofbirth = ?");
            }
            
            if (sex != null && !sex.isEmpty()) {
                appendWhereClause(query, "c.sex LIKE ?");
            }
            
            if (country != null && !country.isEmpty()) {
                appendWhereClause(query, "co.country_name LIKE ?");
            }
            
            if (city != null && !city.isEmpty()) {
                appendWhereClause(query, "ci.city_name LIKE ?");
            }

            if (zip > 0) {
                appendWhereClause(query, "p.postal_code = ?");
            }

            // check the value of the 'sort' parameter and modify the query accordingly
            if (sort != null && !sort.isEmpty()) {
                appendOrderByClause(query, sort);
            }
            
            System.out.println("Query: " + query);

            PreparedStatement pstmt = conn.prepareStatement(query.toString());

            int pIndex = 1;

            if (searchFirstName != null && !searchFirstName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchFirstName + "%");
            }

            if (searchMiddleName != null && !searchMiddleName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchMiddleName + "%");
            }

            if (searchLastName != null && !searchLastName.isEmpty()) {
                pstmt.setString(pIndex++, "%" + searchLastName + "%");
            }

            if (customerId != null && !customerId.isEmpty()) {
                pstmt.setString(pIndex++, customerId);
            }

            if (phone > 0) {
                pstmt.setLong(pIndex++, phone);
            }

            if (birthdate != null) {
                pstmt.setDate(pIndex++, birthdate);
            }
            
            if (sex != null && !sex.isEmpty()) {
                pstmt.setString(pIndex++, sex);
            }

            if (country != null && !country.isEmpty()) {
                pstmt.setString(pIndex++, "%" + country + "%");
            }

            if (city != null && !city.isEmpty()) {
                pstmt.setString(pIndex++, "%" + city + "%");
            }

            if (zip > 0) {
                pstmt.setInt(pIndex++, zip);
            }
            
            System.out.println("Statement: " + pstmt);

            ResultSet rs = pstmt.executeQuery();

            customerList.clear();
            while (rs.next()) {
            Customer customer = new Customer();
            customer.customerId = rs.getInt("customerid");
            customer.completename_First = rs.getString("completename_first");
            customer.completename_Middle = rs.getString("completename_middle");
            customer.completename_Last = rs.getString("completename_last");
            customer.mobile = rs.getLong("phone");
            customer.cntry = rs.getString("country_name");
            customer.citymunicipality = rs.getString("city_name");
            customer.postalCode = rs.getInt("postal_code");
            customer.dateOfBirth = rs.getDate("dateofbirth");
            customer.sex = Sex.valueOf(rs.getString("sex").toUpperCase());
            customer.specialNeeds = rs.getBoolean("specialneeds");

                customerList.add(customer);  
            }

            rs.close();
            pstmt.close();
            conn.close();
            return 1; 
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; 
        }
    }

    
    public int loadCustomer(int customerid) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement(
                "SELECT c.*, co.country_name, ci.city_name, pc.postal_code " +
                "FROM customers c " +
                "JOIN PostalCodes pc ON c.postalcode_id = pc.postalcode " +
                "JOIN Cities ci ON pc.city_id = ci.city_id " +
                "JOIN Countries co ON ci.country_id = co.country_id " +
                "WHERE c.customerid = ?"
            );
            pstmt.setInt(1, customerid);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                this.customerId = rs.getInt("customerid");
                this.completename_First = rs.getString("completename_first");
                this.completename_Middle = rs.getString("completename_middle");
                this.completename_Last = rs.getString("completename_last");
                this.mobile = rs.getLong("phone");
                this.cntry = rs.getString("country_name");
                this.citymunicipality = rs.getString("city_name");
                this.postalCode = rs.getInt("postal_code");
                this.dateOfBirth = rs.getDate("dateofbirth");
                this.sex = Sex.valueOf(rs.getString("sex").toUpperCase());
                this.specialNeeds = rs.getBoolean("specialneeds");
            }
            rs.close();
            pstmt.close();
            conn.close();
            
            return 1; // Success
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Failure
        }
    }

    
    public int createCustomer(
            String completename_First,
            String completename_Middle,
            String completename_Last,
            long mobile,
            String country,
            String cityMunicipality,
            int zipcode,
            Date dateOfBirth,
            Sex sex,
            String specialNeeds) {

        // test if cust. exists
        int ifExistingId = (customerExists(completename_First, completename_Middle,
                completename_Last, dateOfBirth));
        if (ifExistingId != -1) {
            return ifExistingId;
        }

        // Get city_id based on cityMunicipality
        int cityId = getCityId(cityMunicipality);

        // Get postalcode_id based on zipcode and city_id
        int postalCodeId = getPostalCodeId(zipcode, cityId);

        String sql = "INSERT INTO customers (customerid, completename_first, " +
                "completename_last, completename_middle, phone, " +
                "city_id, postalcode_id, dateofbirth, sex, specialneeds)" +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String qry = "SELECT MAX(customerid) + 1 AS newID FROM customers";
        int customerid = 0;

        //get value of new id
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                customerid = rs.getInt("newID");
            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }

        if (customerid == 0)
            customerid += 1001;

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerid);
            pstmt.setString(2, completename_First);
            pstmt.setString(3, completename_Last);
            pstmt.setString(4, completename_Middle);
            pstmt.setLong(5, mobile);
            pstmt.setInt(6, cityId);
            pstmt.setInt(7, postalCodeId);
            pstmt.setDate(8, dateOfBirth);
            pstmt.setString(9, sex.name());
            pstmt.setString(10, specialNeeds);
            
            System.out.println("PSTMT: " + pstmt);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Query: " + sql);
            return 0;
        }
        
        

        return 1; // returns if successfully created
    }

    public int updateCustomer(
        int customerId,
        String completename_First,
        String completename_Last,
        String completename_Middle,
        Long mobile,
        String country,  
        String cityMunicipality,
        int zipcode,
        Date dateOfBirth,
        Sex sex,
        String specialNeeds) {
        String sql = "UPDATE customers SET " +
                "completename_first = ?, " +
                "completename_last = ?, " +
                "completename_middle = ?, " +
                "phone = ?, " +
                "city_id = ?, " +
                "postalcode_id = ?, " +
                "dateofbirth = ?, " +
                "sex = ?, " +
                "specialneeds = ? " +
                "WHERE customerid = ?";
        
        // Get city_id based on cityMunicipality
        int cityId = getCityId(cityMunicipality);

        // Get postalcode_id based on zipcode and city_id
        int postalCodeId = getPostalCodeId(zipcode, cityId);


        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, completename_First);
            pstmt.setString(2, completename_Last);
            pstmt.setString(3, completename_Middle);
            pstmt.setLong(4, mobile);
            pstmt.setInt(5, cityId);
            pstmt.setInt(6, postalCodeId);
            pstmt.setDate(7, dateOfBirth);
            pstmt.setString(8, sex.name());
            pstmt.setString(9, specialNeeds);
            pstmt.setInt(10, customerId);
            
            pstmt.executeUpdate();

            
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }
        
        return 1;
    }
    
    public int deleteCustomer(int customerId) {
        // check if the customer is associated with sales
        String checkSalesSql = "SELECT COUNT(*) AS count FROM sales WHERE customerid = ?";

        // check if the customer is associated with tickets
        String checkTicketsSql = "SELECT COUNT(*) AS count FROM tickets WHERE customerid = ?";

        // check if the customer is associated with reservations
        String checkReservationsSql = "SELECT COUNT(*) AS count FROM reservations r " +
                "JOIN tickets t ON r.ticketid = t.ticketid " +
                "WHERE t.customerid = ?";

        // check if the customer is associated with checkin
        String checkCheckinSql = "SELECT COUNT(*) AS count FROM checkin c " +
                "JOIN reservations r ON c.reservationid = r.reservationid " +
                "JOIN tickets t ON r.ticketid = t.ticketid " +
                "WHERE t.customerid = ?";

        // check if the customer is associated with boarding
        String checkBoardingSql = "SELECT COUNT(*) AS count FROM boarding b " +
                "JOIN checkin c ON b.checkinid = c.checkinid " +
                "JOIN reservations r ON c.reservationid = r.reservationid " +
                "JOIN tickets t ON r.ticketid = t.ticketid " +
                "WHERE t.customerid = ?";

        try (Connection conn = connect();
             PreparedStatement checkSalesStmt = conn.prepareStatement(checkSalesSql);
             PreparedStatement checkTicketsStmt = conn.prepareStatement(checkTicketsSql);
             PreparedStatement checkReservationsStmt = conn.prepareStatement(checkReservationsSql);
             PreparedStatement checkCheckinStmt = conn.prepareStatement(checkCheckinSql);
             PreparedStatement checkBoardingStmt = conn.prepareStatement(checkBoardingSql)) {

            // set customer ID in all prepared statements
            checkSalesStmt.setInt(1, customerId);
            checkTicketsStmt.setInt(1, customerId);
            checkReservationsStmt.setInt(1, customerId);
            checkCheckinStmt.setInt(1, customerId);
            checkBoardingStmt.setInt(1, customerId);

            // execute queries to check dependencies
            ResultSet salesResult = checkSalesStmt.executeQuery();
            int salesCount = 0;
            if (salesResult.next()) {
                salesCount = salesResult.getInt("count");
            }

            ResultSet ticketsResult = checkTicketsStmt.executeQuery();
            int ticketsCount = 0;
            if (ticketsResult.next()) {
                ticketsCount = ticketsResult.getInt("count");
            }

            ResultSet reservationsResult = checkReservationsStmt.executeQuery();
            int reservationsCount = 0;
            if (reservationsResult.next()) {
                reservationsCount = reservationsResult.getInt("count");
            }

            ResultSet checkinResult = checkCheckinStmt.executeQuery();
            int checkinCount = 0;
            if (checkinResult.next()) {
                checkinCount = checkinResult.getInt("count");
            }

            ResultSet boardingResult = checkBoardingStmt.executeQuery();
            int boardingCount = 0;
            if (boardingResult.next()) {
                boardingCount = boardingResult.getInt("count");
            }

            // check if any dependencies exist
            if (salesCount > 0 || ticketsCount > 0 || reservationsCount > 0 || checkinCount > 0 || boardingCount > 0) {
                // customer is associated with other records, do not delete
                return customerId;
            }

            // if no dependencies, proceed with deletion
            String deleteSql = "DELETE FROM customers WHERE customerid = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
                pstmt.setInt(1, customerId);
                pstmt.executeUpdate();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

        return 1;
    }

    private void appendWhereClause(StringBuilder query, String condition) {
        if (query.toString().contains("WHERE")) {
            query.append(" AND ").append(condition);
        } else {
            query.append(" WHERE ").append(condition);
        }
    }
    
    private void appendOrderByClause(StringBuilder query, String sort) {
        query.append(" ORDER BY ");
        switch (sort) {
            case "id":
                query.append("customerid ASC");
                break;
            
            case "az":
                query.append("completename_Last ASC, completename_First ASC, completename_Middle ASC");
                break;
            case "za":
                query.append("completename_Last DESC, completename_First DESC, completename_Middle DESC");
                break;
            case "birthdate":
                query.append("dateofbirth ASC");
                break;
            case "address":
                query.append("cityMunicipality ASC, country ASC");
                break;
        }
    }

    private int customerExists(
        String completename_First,
        String completename_Middle,
        String completename_Last,
        Date dateOfBirth) {

        String sql = "SELECT customerid FROM customers " +
                "WHERE completename_first = ? " +
                "AND completename_last = ? " +
                "AND COALESCE(completename_middle, '') = COALESCE(?, '') " +
                "AND dateofbirth = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, completename_First);
            pstmt.setString(2, completename_Last);
            pstmt.setString(3, completename_Middle);
            pstmt.setDate(4, dateOfBirth);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                return rs.getInt("customerid"); // returns this if exists
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // returns this if doesn't exist
    }

    
    public int loadAddress() {
            Connection conn = connect();
            if (conn == null) {
                System.out.println("Connection failed.");
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT country_name FROM Countries");
                ResultSet rs = pstmt.executeQuery();
                countryList.clear();
                while (rs.next()) {
                    countryList.add(rs.getString("country_name"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT city_name FROM Cities");
                ResultSet rs = pstmt.executeQuery();
                cityList.clear();
                while (rs.next()) {
                    cityList.add(rs.getString("city_name"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                PreparedStatement pstmt = conn.prepareStatement("SELECT DISTINCT postal_code FROM PostalCodes");
                ResultSet rs = pstmt.executeQuery();
                postalList.clear();
                while (rs.next()) {
                    postalList.add(rs.getInt("postal_code"));
                }
                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return 0;
            }

            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

            return 1;
        }

    public ArrayList<String> getCitiesForCountry(String selectedCountry) {
        ArrayList<String> cities = new ArrayList<>();
        // SQL query to select cities in the specified country based on the includeUsedCities flag
        String sql;
        sql = "SELECT c.city_name FROM Cities c " +
              "JOIN Countries co ON c.country_id = co.country_id " +
              "WHERE co.country_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, selectedCountry);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                cities.add(rs.getString("city_name"));
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }

        return cities;
    }



    public ArrayList<Integer> getPostalCodesForCity(String selectedCity) {
        ArrayList<Integer> postalCodes = new ArrayList<>();
        String sql = "SELECT DISTINCT pc.postal_code FROM PostalCodes pc "
                   + "JOIN Cities c ON pc.city_id = c.city_id "
                   + "WHERE c.city_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, selectedCity);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                postalCodes.add(rs.getInt("postal_code"));
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }

        return postalCodes;
    }
    
    private int getCityId(String cityMunicipality) {
        String sql = "SELECT city_id FROM Cities WHERE city_name = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cityMunicipality);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("city_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // City not found
    }

    private int getPostalCodeId(int zipcode, int cityId) {
        String sql = "SELECT postalcode FROM PostalCodes WHERE postal_code = ? AND city_id = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, zipcode);
            pstmt.setInt(2, cityId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("postalcode");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Postal code not found
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCompletename_First() {
        return completename_First;
    }

    public String getCompletename_Middle() {
        return completename_Middle;
    }

    public String getCompletename_Last() {
        return completename_Last;
    }

    public Long getMobile() {
        return mobile;
    }

    public String getCountry() {
        return cntry;
    }


    public String getCitymunicipality() {
        return citymunicipality;
    }

    public int getPostalCode() {
        return postalCode;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public boolean isSpecialNeeds() {
        return specialNeeds;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }
    
    public static void main(String[] args) {
        Customer customerManager = new Customer();
        String sort = null;
        String filterSpecialNeeds = "Y"; 
        String searchFirstName = "John";
        String searchMiddleName = "";
        String searchLastName = "Doe";
        String customerId = null;
        Long phone = 0L;
        Date birthdate = null; 
        String sex = "MALE";
        String country = "USA";
        String city = "New York";
        int zip = 10001;

        int result = customerManager.loadCustomers(sort, filterSpecialNeeds, searchFirstName, 
                                                   searchMiddleName, searchLastName, customerId, 
                                                   phone, birthdate, sex, country, city, zip);

        if (result == 1) {
            System.out.println("Customers loaded successfully.");
            for (Customer customer : customerManager.getCustomerList()) {
                System.out.println("ID: " + customer.getCustomerId() + ", Name: " + customer.getCompletename_First() + 
                                   " " + customer.getCompletename_Last() + ", City: " + customer.getCitymunicipality());
            }
        } else {
            System.out.println("Failed to load customers.");
        }
    }
    
}
