/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Management;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ccslearner
 */
public class Terminal {
    public int airportId;
    public int terminalid;
    public int terminal_number;
    public ArrayList<Terminal> terminals = new ArrayList<>();
     public ArrayList<String> tableNamesWithTerminalNumber = new ArrayList<>();
     
     
    public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }


    
        public int loadTerminals() {
        Connection conn = connect();
        if (conn == null) {
            return 0; 
        }
        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM terminals");
            ResultSet rs = pstmt.executeQuery();
            terminals.clear();
            while (rs.next()) {
                Terminal terminal = new Terminal();
                terminal.terminalid = rs.getInt("terminalid");
                terminal.airportId = rs.getInt("airportId");
                terminal.terminal_number = rs.getInt("terminal_number");
                terminals.add(terminal);
            }
            rs.close();
            pstmt.close();
            conn.close();
            return 1; 
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
        
    public int airportTerminal(int airportId) {
    Connection conn = connect();
    if (conn == null) {
        return 0; 
    }
    try {
        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM terminals WHERE airportId = ?");
        pstmt.setInt(1, airportId);

        ResultSet rs = pstmt.executeQuery();
        terminals.clear();
        while (rs.next()) {
            Terminal terminal = new Terminal();
            terminal.terminalid = rs.getInt("terminalid");
            terminal.airportId = rs.getInt("airportId");
            terminal.terminal_number = rs.getInt("terminal_number");
            terminals.add(terminal);
        }
        rs.close();
        pstmt.close();
        conn.close();
        return 1; 
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0;
    }
}

   public int findTablesRelatedToTerminal(int searchAirportId, int searchTerminalNumber) {
    String sqlGetTerminalId = "SELECT terminalid FROM terminals WHERE airportid = ? AND terminal_number = ?";
    Connection conn = connect();

    if (conn == null) {
        System.out.println("Connection failed.");
        return 0;
    }

    tableNamesWithTerminalNumber.clear();

    try (PreparedStatement pstmtGetTerminalId = conn.prepareStatement(sqlGetTerminalId)) {
        pstmtGetTerminalId.setInt(1, searchAirportId);
        pstmtGetTerminalId.setInt(2, searchTerminalNumber);
        ResultSet rsTerminalId = pstmtGetTerminalId.executeQuery();

        if (rsTerminalId.next()) {
            int terminalId = rsTerminalId.getInt("terminalid");

            String sqlFindForeignKeyTables = "SELECT DISTINCT kcu.table_name " +
                    "FROM information_schema.table_constraints AS tc " +
                    "JOIN information_schema.key_column_usage AS kcu " +
                    "ON tc.constraint_name = kcu.constraint_name " +
                    "WHERE tc.constraint_type = 'FOREIGN KEY' " +
                    "AND tc.table_schema = 'hello' " + 
                    "AND kcu.referenced_table_name = 'terminals' " +
                    "AND kcu.referenced_table_schema = 'hello' " + 
                    "AND kcu.referenced_column_name = 'terminalid'";

            try (PreparedStatement pstmtFindForeignKeyTables = conn.prepareStatement(sqlFindForeignKeyTables)) {
                ResultSet rsForeignKeyTables = pstmtFindForeignKeyTables.executeQuery();
                while (rsForeignKeyTables.next()) {
                    String tableName = rsForeignKeyTables.getString("table_name");
                    tableNamesWithTerminalNumber.add(tableName);
                }
            } catch (SQLException e) {
                System.out.println("Error finding foreign key tables: " + e.getMessage());
            }
        } else {
            System.out.println("No terminal found with the specified airportid and terminal_number.");
        }
        return 1;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}



    public int addTerminal(int airportId, int terminal_number) {
        String sql = "INSERT INTO terminals (airportid, terminal_number) VALUES (?, ?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, airportId);
            pstmt.setInt(2, terminal_number);
            pstmt.executeUpdate();
            return 1; 
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; 
        }
    }
    
    public int deleteTerminal(int airportId, int terminal_number) {
    String sql = "DELETE FROM terminals WHERE airportid = ? AND terminal_number = ?";
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, airportId);
        pstmt.setInt(2, terminal_number);
        pstmt.executeUpdate();
        return 1;
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
}

     
    public int viewTerminal(int airportId, int terminalNumber) {
    Connection conn = connect();
    if (conn == null) {
        System.out.println("Connection failed.");
        return 0; 
    }
    try {
        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM terminals WHERE airportId = ? AND terminal_number = ?");
        pstmt.setInt(1, airportId);
        pstmt.setInt(2, terminalNumber);

        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            this.terminalid = rs.getInt("terminalid");
            this.airportId = rs.getInt("airportId");
            this.terminal_number = rs.getInt("terminal_number");

            System.out.println("Terminal ID: " + this.terminalid + 
                               ", Airport ID: " + this.airportId + 
                               ", Terminal Number: " + this.terminal_number);
        } else {
            System.out.println("Terminal not found.");
            return 0; 
        }

        rs.close();
        pstmt.close();
        conn.close();
        return 1;
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return 0; 
    }
}


    public static void main(String[] args) {
    Terminal terminalManager = new Terminal();
    System.out.println("Testing loadTerminals");
    int loadResult = terminalManager.loadTerminals();

    System.out.println("\nTesting findTablesRelatedToTerminal for Terminal ID 1 and Airport ID 1");
    int findResult = terminalManager.findTablesRelatedToTerminal(1, 1); 
    System.out.println("findTablesRelatedToTerminal result: " + findResult);
    for (String tableName : terminalManager.tableNamesWithTerminalNumber) {
        System.out.println("Related Table: " + tableName);
    }
}


}
