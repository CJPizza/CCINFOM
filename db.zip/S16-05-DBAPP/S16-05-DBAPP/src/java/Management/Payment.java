
package Management;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.text.DateFormatSymbols;
public class Payment {
    public enum PaymentStatus {
        Canceled, Pending, Completed
    }
    public enum Method {
        Cash, CreditCard, DebitCard, Other
    }
    public enum Class {
        Economy, Business, First
    }
    public int saleID;
    public int customerID;
    public int flightID;
    public Date transactionDate;
    public String transactionMonth;
    public double amountpayed;
    public double total;
    public Method method;
    public PaymentStatus status;
    public Class seatClass;
    public int ticketsbooked;
    public List<Payment> paymentList = new ArrayList<>();
    public Payment() {
    }
    
    public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            java.lang.Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }


    
    public static class SalesResult {
        private int flightId;
        private int salesCount;
        private double totalAmount;
        private String arrival;
        private String custCountry;
        private String custSex;

        // Constructor
        public SalesResult(int flightId, int salesCount, double totalAmount) {
            this.flightId = flightId;
            this.salesCount = salesCount;
            this.totalAmount = totalAmount;
        }
        
        public SalesResult(int flightId, int salesCount, double totalAmount,
                           String arrival) {
            this.flightId = flightId;
            this.salesCount = salesCount;
            this.totalAmount = totalAmount;
            this.arrival = arrival;
        }
        
        public SalesResult(String custCountry, int salesCount, double totalAmount) {
            this.salesCount = salesCount;
            this.totalAmount = totalAmount;
            this.custCountry = custCountry;
        }

        public SalesResult(int salesCount, double totalAmount, String custSex) {
            this.salesCount = salesCount;
            this.totalAmount = totalAmount;
            this.custSex = custSex;
        }
        
        public int getFlightId() {
            return flightId;
        }

        public int getSalesCount() {
            return salesCount;
        }

        public double getTotalAmount() {
            return totalAmount;
        }
        
        public String getArrival() {
            return arrival;
        }
        
        public String getCustCountry() {
            return custCountry;
        }
        
        public String getCustSex() {
            return custSex;
        }
    }

    public List<SalesResult> getSalesByFlight(String selectedMonth, 
                                            String selectedQuarter, 
                                            String enteredYear) {
        List<SalesResult> results = new ArrayList<>();

        try {
            String query = "SELECT flightid, " +
                       "COUNT(saleid) AS sales_count, " +
                       "SUM(amountpayed) AS total_amount FROM sales " +
                       "WHERE 1=1";
            
            // Add conditions for month, quarter, and year if provided
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                query += " AND MONTH(transactiondate) = ?";
            }
            
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                query += " AND (QUARTER(transactiondate) = ? "
                        + "OR (MONTH(transactiondate) >= 1 "
                        + "AND MONTH(transactiondate) <= 3 "
                        + "AND ? = 'q1') OR (MONTH(transactiondate) >= 4 "
                        + "AND MONTH(transactiondate) <= 6 "
                        + "AND ? = 'q2') OR (MONTH(transactiondate) >= 7 "
                        + "AND MONTH(transactiondate) <= 9 AND ? = 'q3') "
                        + "OR (MONTH(transactiondate) >= 10 "
                        + "AND MONTH(transactiondate) <= 12 "
                        + "AND ? = 'q4')) ";
            }
            
            if (enteredYear != null && !enteredYear.isEmpty()) {
                query += " AND YEAR(transactiondate) = ?";
            }

            query += " GROUP BY flightid;";

            Connection conn = connect();
            if (conn == null) {
                return null; // Connection failed
            }

            PreparedStatement pstmt = conn.prepareStatement(query);
            
            // Set parameters based on the provided values
            int paramIndex = 1;
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                pstmt.setString(paramIndex++, selectedMonth);
            }
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                for (int i = 0; i <= 4; i++) {
                    pstmt.setString(paramIndex++, selectedQuarter);
                }
            }
            if (enteredYear != null && !enteredYear.isEmpty()) {
                pstmt.setString(paramIndex, enteredYear);
            }
            
            System.out.println("STATMENET!: " + pstmt);
            
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int flightId = rs.getInt("flightid");
                int salesCount = rs.getInt("sales_count");
                double totalAmount = rs.getDouble("total_amount");

                SalesResult result = new SalesResult(flightId, salesCount, totalAmount);
                results.add(result);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return results;
    }

    // Helper method to create destination-based report
    public List<SalesResult> getSalesByDestination(String selectedMonth, 
                                            String selectedQuarter, 
                                            String enteredYear) {
        List<SalesResult> results = new ArrayList<>();

        try {
            String query = "SELECT f.flightid, a.name AS destination_airport, "
                    + "COUNT(s.saleid) AS sales_count, SUM(s.amountpayed) AS total_amount "
                    + "FROM sales s JOIN flights f "
                    + "ON s.flightid = f.flightid "
                    + "JOIN airports a "
                    + "ON f.arrivalairport = a.airportid "
                    + "WHERE 1=1";
            
            // Add conditions for month, quarter, and year if provided
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                query += " AND MONTH(transactiondate) = ?";
            }
            
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                query += " AND (QUARTER(transactiondate) = ? "
                        + "OR (MONTH(transactiondate) >= 1 "
                        + "AND MONTH(transactiondate) <= 3 "
                        + "AND ? = 'q1') OR (MONTH(transactiondate) >= 4 "
                        + "AND MONTH(transactiondate) <= 6 "
                        + "AND ? = 'q2') OR (MONTH(transactiondate) >= 7 "
                        + "AND MONTH(transactiondate) <= 9 AND ? = 'q3') "
                        + "OR (MONTH(transactiondate) >= 10 "
                        + "AND MONTH(transactiondate) <= 12 "
                        + "AND ? = 'q4')) ";
            }
            
            if (enteredYear != null && !enteredYear.isEmpty()) {
                query += " AND YEAR(transactiondate) = ?";
            }

            query += " GROUP BY f.flightid, a.name;;";

            Connection conn = connect();
            if (conn == null) {
                return null; // Connection failed
            }

            PreparedStatement pstmt = conn.prepareStatement(query);
            
            // Set parameters based on the provided values
            int paramIndex = 1;
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                pstmt.setString(paramIndex++, selectedMonth);
            }
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                for (int i = 0; i <= 4; i++) {
                    pstmt.setString(paramIndex++, selectedQuarter);
                }
            }
            if (enteredYear != null && !enteredYear.isEmpty()) {
                pstmt.setString(paramIndex, enteredYear);
            }
            
            System.out.println("STATMENET!: " + pstmt);
            
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int flightId = rs.getInt("flightid");
                int salesCount = rs.getInt("sales_count");
                double totalAmount = rs.getDouble("total_amount");
                String destinationAirport = rs.getString("destination_airport");

                SalesResult result = new SalesResult(flightId, salesCount, totalAmount,
                                                destinationAirport);
                results.add(result);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return results;
    }
    
    public List<SalesResult> getSalesByCustCountry(String selectedMonth, 
                                            String selectedQuarter, 
                                            String enteredYear) {
        List<SalesResult> results = new ArrayList<>();

        try {
            String query = "SELECT c.country_name AS customer_country, "
                    + "COUNT(s.saleid) AS sales_count, SUM(s.amountpayed) AS total_amount "
                    + "FROM sales s JOIN customers cust ON s.customerid = cust.customerid "
                    + "JOIN Cities ci ON cust.city_id = ci.city_id "
                    + "JOIN Countries c ON ci.country_id = c.country_id "
                    + "WHERE 1=1";
            
            // Add conditions for month, quarter, and year if provided
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                query += " AND MONTH(transactiondate) = ?";
            }
            
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                query += " AND (QUARTER(transactiondate) = ? "
                        + "OR (MONTH(transactiondate) >= 1 "
                        + "AND MONTH(transactiondate) <= 3 "
                        + "AND ? = 'q1') OR (MONTH(transactiondate) >= 4 "
                        + "AND MONTH(transactiondate) <= 6 "
                        + "AND ? = 'q2') OR (MONTH(transactiondate) >= 7 "
                        + "AND MONTH(transactiondate) <= 9 AND ? = 'q3') "
                        + "OR (MONTH(transactiondate) >= 10 "
                        + "AND MONTH(transactiondate) <= 12 "
                        + "AND ? = 'q4')) ";
            }
            
            if (enteredYear != null && !enteredYear.isEmpty()) {
                query += " AND YEAR(transactiondate) = ?";
            }

            query += " GROUP BY c.country_name;";

            Connection conn = connect();
            if (conn == null) {
                return null; // Connection failed
            }

            PreparedStatement pstmt = conn.prepareStatement(query);
            
            // Set parameters based on the provided values
            int paramIndex = 1;
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                pstmt.setString(paramIndex++, selectedMonth);
            }
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                for (int i = 0; i <= 4; i++) {
                    pstmt.setString(paramIndex++, selectedQuarter);
                }
            }
            if (enteredYear != null && !enteredYear.isEmpty()) {
                pstmt.setString(paramIndex, enteredYear);
            }
            
            System.out.println("STATMENET!: " + pstmt);
            
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String custCountry = rs.getString("customer_country");
                int salesCount = rs.getInt("sales_count");
                double totalAmount = rs.getDouble("total_amount");

                SalesResult result = new SalesResult(custCountry, salesCount, totalAmount);
                results.add(result);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return results;
    }
    
    public List<SalesResult> getSalesByCustSex(String selectedMonth, 
                                            String selectedQuarter, 
                                            String enteredYear) {
        List<SalesResult> results = new ArrayList<>();

        try {
            String query = "SELECT cust.sex AS customer_sex, "
                    + "COUNT(s.saleid) AS sales_count, SUM(s.amountpayed) AS total_amount "
                    + "FROM sales s JOIN customers cust ON s.customerid = cust.customerid "
                    + "WHERE 1=1";
            
            // Add conditions for month, quarter, and year if provided
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                query += " AND MONTH(transactiondate) = ?";
            }
            
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                query += " AND (QUARTER(transactiondate) = ? "
                        + "OR (MONTH(transactiondate) >= 1 "
                        + "AND MONTH(transactiondate) <= 3 "
                        + "AND ? = 'q1') OR (MONTH(transactiondate) >= 4 "
                        + "AND MONTH(transactiondate) <= 6 "
                        + "AND ? = 'q2') OR (MONTH(transactiondate) >= 7 "
                        + "AND MONTH(transactiondate) <= 9 AND ? = 'q3') "
                        + "OR (MONTH(transactiondate) >= 10 "
                        + "AND MONTH(transactiondate) <= 12 "
                        + "AND ? = 'q4')) ";
            }
            
            if (enteredYear != null && !enteredYear.isEmpty()) {
                query += " AND YEAR(transactiondate) = ?";
            }

            query += " GROUP BY cust.sex;";

            Connection conn = connect();
            if (conn == null) {
                return null; // Connection failed
            }

            PreparedStatement pstmt = conn.prepareStatement(query);
            
            // Set parameters based on the provided values
            int paramIndex = 1;
            if (selectedMonth != null && !selectedMonth.isEmpty()) {
                pstmt.setString(paramIndex++, selectedMonth);
            }
            if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
                for (int i = 0; i <= 4; i++) {
                    pstmt.setString(paramIndex++, selectedQuarter);
                }
            }
            if (enteredYear != null && !enteredYear.isEmpty()) {
                pstmt.setString(paramIndex, enteredYear);
            }
            
            System.out.println("STATMENET!: " + pstmt);
            
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String custSex = rs.getString("customer_sex");
                int salesCount = rs.getInt("sales_count");
                double totalAmount = rs.getDouble("total_amount");

                SalesResult result = new SalesResult(salesCount, totalAmount, custSex);
                results.add(result);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

        return results;
    }
    
    public List<Payment> filterPayments(
            String month, 
            String quarter, 
            String year, 
            String flightId, 
            String departureAirport, 
            String destinationAirport, 
            String customerAgeGroup, 
            String methodOfPayment, 
            String statusOfSales, 
            String classOfSales) {
        Connection conn = connect();
        if (conn == null) {
            return null; // Connection failed
        }

        try {
           StringBuilder query = new StringBuilder("SELECT " +
            "s.saleid, " +
            "s.customerid, " +
            "s.flightid, " +
            "s.amountpayed, " +
            "s.transactiondate, " +
            "s.transactionmonth, " +
            "s.total, " +
            "s.method, " +
            "s.status, " +
            "s.ticketsbooked, " +
            "b.SeatNumber, " +
            "b.BookingStatus, " +
            "st.class AS SeatClass, " +
            "st.status AS SeatStatus, " +
            "seats.class AS SeatClassFromSeats " + // Add this line to select the class from the seats table
            "FROM sales s " +
            "JOIN customers c ON s.customerid = c.customerid " +
            "JOIN airports d_airport ON s.flightid = d_airport.airportid " +
            "JOIN flights f ON s.flightid = f.flightid " +
            "JOIN airports a_airport ON f.arrivalairport = a_airport.airportid " +
            "JOIN Bookings b ON s.flightid = b.FlightID " +
            "JOIN seats st ON b.FlightID = st.flight_id AND b.SeatNumber = st.seat_number " +
            "JOIN seats ON s.flightid = seats.flight_id AND b.SeatNumber = seats.seat_number " + // Add this line to join seats again
            "WHERE 1=1 ");

            // Add filter conditions based on the provided parameters
            if (month != null && !month.isEmpty()) {
                query.append("AND MONTH(transactiondate) = ? ");
            }

            if (quarter != null && !quarter.isEmpty()) {
                query.append("AND (QUARTER(transactiondate) = ? "
                        + "OR (MONTH(transactiondate) >= 1 "
                        + "AND MONTH(transactiondate) <= 3 "
                        + "AND ? = 'q1') OR (MONTH(transactiondate) >= 4 "
                        + "AND MONTH(transactiondate) <= 6 "
                        + "AND ? = 'q2') OR (MONTH(transactiondate) >= 7 "
                        + "AND MONTH(transactiondate) <= 9 AND ? = 'q3') "
                        + "OR (MONTH(transactiondate) >= 10 "
                        + "AND MONTH(transactiondate) <= 12 "
                        + "AND ? = 'q4')) ");
            }

            if (year != null && !year.isEmpty()) {
                query.append("AND YEAR(transactiondate) = ? ");
            }

            if (flightId != null && !flightId.isEmpty()) {
                query.append("AND f.flightid = ? ");
            }

            if (departureAirport != null && !departureAirport.isEmpty()) {
                query.append("AND d_airport.name = ? ");
            }

            if (destinationAirport != null && !destinationAirport.isEmpty()) {
                query.append("AND a_airport.name = ? ");
            }

            if (customerAgeGroup != null && !customerAgeGroup.isEmpty()) {
                switch (customerAgeGroup) {
                    case "Minor":
                        query.append("AND YEAR(CURDATE()) - YEAR(c.dateofbirth) < 18 ");
                        break;
                    case "Adult":
                        query.append("AND YEAR(CURDATE()) - YEAR(c.dateofbirth) >= 18 ");
                        break;
                    default:
                        return null; 
                }
            }

            if (methodOfPayment != null && !methodOfPayment.isEmpty()) {
                query.append("AND s.method = ? ");
            }

            if (statusOfSales != null && !statusOfSales.isEmpty()) {
                query.append("AND s.status = ? ");
            }

            if (classOfSales != null && !classOfSales.isEmpty()) {
                query.append("AND st.class = ? ");
            }
            
            System.out.println("QUERY!!!!!!!!!: " + query);

            PreparedStatement pstmt = conn.prepareStatement(query.toString());

            // Set parameters based on the provided values
            int parameterIndex = 1;

            if (month != null && !month.isEmpty()) {
                pstmt.setInt(parameterIndex++, Integer.parseInt(month));
            }

            if (quarter != null && !quarter.isEmpty()) {
                for (int i = 0; i <= 4; i++) {
                    pstmt.setString(parameterIndex++, quarter);
                }
            }

            if (year != null && !year.isEmpty()) {
                pstmt.setInt(parameterIndex++, Integer.parseInt(year));
            }

            if (flightId != null && !flightId.isEmpty()) {
                pstmt.setString(parameterIndex++, flightId);
            }

            if (departureAirport != null && !departureAirport.isEmpty()) {
                pstmt.setString(parameterIndex++, departureAirport);
            }

            if (destinationAirport != null && !destinationAirport.isEmpty()) {
                pstmt.setString(parameterIndex++, destinationAirport);
            }

            if (methodOfPayment != null && !methodOfPayment.isEmpty()) {
                pstmt.setString(parameterIndex++, methodOfPayment);
            }

            if (statusOfSales != null && !statusOfSales.isEmpty()) {
                pstmt.setString(parameterIndex++, statusOfSales);
            }

            if (classOfSales != null && !classOfSales.isEmpty()) {
                pstmt.setString(parameterIndex++, classOfSales);
            }
            
            System.out.println("STATMENET!: " + pstmt);

            ResultSet rs = pstmt.executeQuery();

            List<Payment> filteredPayments = new ArrayList<>();
            while (rs.next()) {
                // Create Payment objects based on the query result
                Payment payment = new Payment();
                    // Set attributes based on the query result
                    payment.saleID = rs.getInt("saleid");
                    payment.customerID = rs.getInt("customerid");
                    payment.flightID = rs.getInt("flightid");
                    payment.transactionDate = rs.getDate("transactiondate");
                    payment.transactionMonth = rs.getString("transactionmonth");
                    payment.amountpayed = rs.getDouble("amountpayed");
                    payment.total = rs.getDouble("total");

                    // Set Method enum based on the method column in the query result
                    String methodString = rs.getString("method");
                    payment.method = Method.valueOf(methodString);

                    // Set PaymentStatus enum based on the status column in the query result
                    String statusString = rs.getString("status");
                    payment.status = PaymentStatus.valueOf(statusString);

                    // Set Class enum based on the class column in the query result
                   
                    payment.seatClass = Class.valueOf(rs.getString("seatclass"));

                    payment.ticketsbooked = rs.getInt("ticketsbooked");
                // Set other attributes...
                filteredPayments.add(payment);
            }

            rs.close();
            pstmt.close();
            conn.close();

            return filteredPayments;
        } catch (SQLException e) {
            e.printStackTrace();
            return null; // Error occurred
        }
    }

   public int loadPayment(String saleid, String customerId) {
        Connection conn = connect();
        if (conn == null) {
            return 0; // Connection failed
        }
        try {
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.append("SELECT ");
            queryBuilder.append("s.saleid, ");
            queryBuilder.append("s.customerid, ");
            queryBuilder.append("s.flightid, ");
            queryBuilder.append("s.amountpayed, ");
            queryBuilder.append("s.transactiondate, ");
            queryBuilder.append("s.transactionmonth, ");
            queryBuilder.append("s.total, ");
            queryBuilder.append("s.method, ");
            queryBuilder.append("s.status, ");
            queryBuilder.append("s.ticketsbooked, ");
            queryBuilder.append("b.SeatNumber, ");
            queryBuilder.append("b.BookingStatus, ");
            queryBuilder.append("st.class AS SeatClass, ");
            queryBuilder.append("st.status AS SeatStatus ");
            queryBuilder.append("FROM hello.sales s ");
            queryBuilder.append("JOIN hello.Bookings b ON s.flightid = b.FlightID ");
            queryBuilder.append("JOIN hello.seats st ON b.FlightID = st.flight_id AND b.SeatNumber = st.seat_number");
            // Add conditions for searching by saleid and customerId
            if (saleid != null && !saleid.isEmpty()) {
                queryBuilder.append(" AND s.saleid = ?");
            }
            if (customerId != null && !customerId.isEmpty()) {
                queryBuilder.append(" AND s.customerID = ?");
            }
            PreparedStatement pstmt = conn.prepareStatement(queryBuilder.toString());
            // Set parameters based on conditions
            int parameterIndex = 1;
            if (saleid != null && !saleid.isEmpty()) {
                pstmt.setString(parameterIndex++, saleid);
            }
            if (customerId != null && !customerId.isEmpty()) {
                pstmt.setString(parameterIndex++, customerId);
            }
            ResultSet rs = pstmt.executeQuery();
            paymentList.clear();
            while (rs.next()) {
                Payment payment = new Payment();
                payment.saleID = rs.getInt("saleID");
                payment.customerID = rs.getInt("customerID");
                payment.flightID = rs.getInt("flightID");
                payment.transactionDate = rs.getDate("transactionDate");
                payment.transactionMonth = rs.getString("transactionMonth");
                payment.amountpayed = rs.getDouble("amountpayed");
                payment.total = rs.getDouble("total");
                payment.seatClass = Class.valueOf(rs.getString("seatclass"));
                payment.method = Method.valueOf(rs.getString("method"));
                payment.status = PaymentStatus.valueOf(rs.getString("status"));
                payment.ticketsbooked = rs.getInt("ticketsbooked");
                paymentList.add(payment);
            }
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int viewCustomer(int salesid) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
            System.out.println("Connection Successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM sales WHERE salesid = ?");
            pstmt.setInt(1, salesid);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                this.saleID = rs.getInt("saleid");
                this.customerID = rs.getInt("customerID");
                this.flightID = rs.getInt("flightID");
                this.transactionDate = rs.getDate("transactionDate");
                this.amountpayed = rs.getDouble("amountpayed");
                this.total = rs.getDouble("total");
                this.method = Method.valueOf(rs.getString("method"));
                this.ticketsbooked = rs.getInt("ticketsbooked");
            }

            rs.close();
            pstmt.close();
            conn.close();
            return 1; // Success
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Failure
        }
    }

    public int createPayment(int saleid, int customerID, int flightID, Date transactionDate, double amountpayed, Method method) {
    int ticketsbooked = getPendingandConfirmedTickets(customerID);
    double total = getTicketPriceSolo(customerID, flightID);

    // Extracting the month from the transaction date
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(transactionDate);
    int transactionMonth = calendar.get(Calendar.MONTH) + 1; // Adding 1 because months are 0-based

    // Convert the month number to its respective name
    String[] monthNames = new DateFormatSymbols().getMonths();
    String monthName = monthNames[transactionMonth - 1]; // Subtracting 1 to get correct index

    String sql = "INSERT INTO sales (saleid, customerid, " +
            "flightid, transactiondate, transactionmonth, amountpayed, " +
            "total, method, ticketsbooked)" +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, saleid);
        pstmt.setInt(2, customerID);
        pstmt.setInt(3, flightID);
        pstmt.setDate(4, transactionDate);
        pstmt.setString(5, monthName);
        pstmt.setDouble(6, amountpayed);
        pstmt.setDouble(7, total);
        pstmt.setString(8, method.name());
        pstmt.setInt(9, ticketsbooked);

        pstmt.executeUpdate();
    } catch (SQLIntegrityConstraintViolationException e) {
        // Handle primary key violation (duplicate saleid)
        System.out.println("Error: Duplicate entry for saleid " + saleid);
        return 0;
    } catch (SQLException e) {
        e.printStackTrace();
        System.out.println("SQL Query: " + sql);
        System.out.println("Failed: " + e.getMessage());
        return 0;
    }

    return 1;
}

    public static double getTotalAmountPaidForFlight(int customerID, int flightId) {
    double totalAmountPaid = 0;

    String sql = "SELECT SUM(amountpayed) AS totalAmountPaid FROM sales WHERE customerid = ? AND flightid = ?";

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setInt(1, customerID);
        pstmt.setInt(2, flightId);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                totalAmountPaid = rs.getDouble("totalAmountPaid");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        System.out.println("SQL Query: " + sql);
        System.out.println("Failed: " + e.getMessage());
    }

    return totalAmountPaid;
}



    public int updatePayment(int saleID, int customerID, int flightID, Date transactionDate, String transactionMonth, double amountPayed, Method method, int ticketsbooked) {
        //double total = getTicketPrice( seatClass, ticketsbooked);

        String sql = "UPDATE sales SET " +
                "customerID = ?, " +
                "flightID = ?, " +
                "transactionDate = ?, " +
                "transactionMonth = ?, " +
                "amountPayed = ?, " +
                "total = ?, " +
                "method = ?, " +
                "status = ?, " +
                "ticketsbooked = ? " +
                "WHERE saleID = ?";

        try (Connection conn = connect();
             PreparedStatement pstmtStaff = conn.prepareStatement(sql)) {
            pstmtStaff.setInt(1, customerID);
            pstmtStaff.setInt(2, flightID);
            pstmtStaff.setDate(3, transactionDate);
            pstmtStaff.setString(4, transactionMonth);
            pstmtStaff.setDouble(5, amountPayed);
            pstmtStaff.setDouble(6, total);
            pstmtStaff.setString(7, method.name());
            pstmtStaff.setString(8, status.name());
            pstmtStaff.setInt(9, ticketsbooked);

            pstmtStaff.setInt(10, saleID);

            pstmtStaff.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed: " + e.getMessage());
            return 0; // Error occurred
        }

        return 1;
    }
    
  public int updateBookingStatus(int customerId, int flightId, String newStatus) {
    String query = "UPDATE Bookings SET BookingStatus = ? WHERE CustomerID = ? AND FlightID = ?";
      try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        // Assuming newStatus is a valid ENUM value for BookingStatus
        preparedStatement.setString(1, newStatus);
        preparedStatement.setInt(2, customerId);
        preparedStatement.setInt(3, flightId);

        return preparedStatement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        return -1;  // You can choose an appropriate value to indicate an error
    }
}


public int updateSaleStatus(int customerId, int flightId, String newStatus) {
    String query = "UPDATE sales SET status = ? WHERE customerid = ? AND flightid = ?";
    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setString(1, newStatus);
        preparedStatement.setInt(2, customerId);
        preparedStatement.setInt(3, flightId);

        return preparedStatement.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        return -1;  // You can choose an appropriate value to indicate an error
    }
}


public static List<Integer> getSaleIdsByCustomerId(int customerid) {
    List<Integer> saleIds = new ArrayList<>();
    String query = "SELECT saleid FROM sales WHERE customerid = ?";

      try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement pstmt = conn.prepareStatement(query)) {

        pstmt.setInt(1, customerid);

        try (ResultSet resultSet = pstmt.executeQuery()) {
            while (resultSet.next()) {
                int saleId = resultSet.getInt("saleid");
                saleIds.add(saleId);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }

    return saleIds;
}

public static void updateCustomerPaymentInfo(int customerid, double total, int saleID) {
    String updateQuery = "UPDATE sales SET total = ? WHERE customerid = ? AND saleid = ?";

      try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {

        pstmt.setDouble(1, total);
        pstmt.setInt(2, customerid);
        pstmt.setInt(3, saleID);

        int rowsUpdated = pstmt.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("Customer payment info updated successfully");
        } else {
            System.out.println("No records found for customer ID: " + customerid + " and sale ID: " + saleID);
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }
}

public static void updateAllCustomerPaymentInfo(int customerid, double total) {
    // Get the sale IDs for the customer
    List<Integer> saleIds = getSaleIdsByCustomerId(customerid);

    // Update each record with the new total
    for (int saleId : saleIds) {
        updateCustomerPaymentInfo(customerid, total, saleId);
    }
}


    public int deletePayment(int salesID) {
        String sql = "DELETE FROM sales WHERE salesID = ?";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, salesID);

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }

        return 1;
    }

  
   public static int getPendingandConfirmedTickets(int customerId) {
    String query = "SELECT COUNT(*) AS num_tickets FROM Bookings WHERE customerid = ? AND `BookingStatus` IN ('Pending', 'Confirmed')";

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setInt(1, customerId);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getInt("num_tickets");
            }
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }

    return 0; // Return 0 if there is an issue or no tickets found
}
   public static double getTicketPriceSolo(int customerId, int flightId) {
    String query = "SELECT s.class " +
                   "FROM Bookings b " +
                   "JOIN seats s ON b.FlightID = s.flight_id AND b.SeatNumber = s.seat_number " +
                   "WHERE b.CustomerID = ? AND b.FlightID = ? AND b.BookingStatus IN ('Pending', 'Confirmed')";

    Class seatClass = null;

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setInt(1, customerId);
        preparedStatement.setInt(2, flightId);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                String seatClassString = resultSet.getString("class");
                seatClass = Class.valueOf(seatClassString);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return -1.0;  // You can choose an appropriate value to indicate an error
    }

    if (seatClass != null) {
        return getTicketPrice(flightId, seatClass);
    } else {
        return -1.0;  // You can choose an appropriate value to indicate that the seat class was not found
    }
}

   
public static double getTotalTicketPrice(int customerId) {
    String query = "SELECT b.FlightID, s.class " +
                   "FROM Bookings b " +
                   "JOIN seats s ON b.FlightID = s.flight_id AND b.SeatNumber = s.seat_number " +
                   "WHERE b.CustomerID = ? AND b.BookingStatus IN ('Pending', 'Confirmed')";

    List<Pair<Integer, Class>> flightAndClassList = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setInt(1, customerId);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int flightId = resultSet.getInt("FlightID");
                String seatClassString = resultSet.getString("class");
                Class seatClass = Class.valueOf(seatClassString); 
                flightAndClassList.add(new Pair<>(flightId, seatClass));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); 
        return -1.0; 
    }
   
    double totalTicketPrice = 0.0;

    
    for (Pair<Integer, Class> flightAndClass : flightAndClassList) {
        double ticketPrice = getTicketPrice(flightAndClass.getFirst(), flightAndClass.getSecond());
        totalTicketPrice += ticketPrice;
    }

    return totalTicketPrice;
}


public static double getTicketPrice(int flightId, Class seatClass) {
    String sql = "SELECT ticketprice FROM flights WHERE flightid = ?";

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setInt(1, flightId);

        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                BigDecimal baseTicketPrice = rs.getBigDecimal("ticketprice");
                return calculateTotalPrice(baseTicketPrice, seatClass).doubleValue();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception as needed
    }

    return 0.0; // Or throw an exception, return a default value, etc.
}


private static BigDecimal calculateTotalPrice(BigDecimal baseTicketPrice, Class seatClass) {
    // Define multipliers for each seat class
    int economyMultiplier = 1;  // Regular price
    int businessMultiplier = 2;  // Business class is 2 times the regular price
    int firstClassMultiplier = 4; // First class is 4 times the regular price

    // Calculate total price based on seat class
    switch (seatClass) {
        case Economy:
            return baseTicketPrice.multiply(BigDecimal.valueOf(economyMultiplier));
        case Business:
            return baseTicketPrice.multiply(BigDecimal.valueOf(businessMultiplier));
        case First:
            return baseTicketPrice.multiply(BigDecimal.valueOf(firstClassMultiplier));
        default:
            throw new IllegalArgumentException("Invalid seat class: " + seatClass);
    }
}

 public static List<Integer> getFlightPendingInt(int customerId) {
        String query = "SELECT FlightID FROM Bookings WHERE customerid = ? AND `BookingStatus` IN ('Pending')";

        List<Integer> flightIds = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
             PreparedStatement preparedStatement = conn.prepareStatement(query)) {

            preparedStatement.setInt(1, customerId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int flightId = resultSet.getInt("FlightID");
                    flightIds.add(flightId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your needs
        }

        return flightIds;
    }


    public static List<Pair<Integer, Class>> getFlightIdsPending(int customerId) {
    String query = "SELECT b.FlightID, s.class " +
                   "FROM Bookings b " +
                   "JOIN seats s ON b.FlightID = s.flight_id AND b.SeatNumber = s.seat_number " +
                   "WHERE b.CustomerID = ? AND b.BookingStatus = 'Pending'";

    List<Pair<Integer, Class>> flightAndClassList = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setInt(1, customerId);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int flightId = resultSet.getInt("FlightID");
                String seatClassString = resultSet.getString("class");
                Class seatClass = Class.valueOf(seatClassString); // Assuming Class is your Enum
                flightAndClassList.add(new Pair<>(flightId, seatClass));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }
    return flightAndClassList;
}


   public static List<Pair<Integer, Class>> getFlightIdsPaid(int customerId) {
    String query = "SELECT b.FlightID, s.class " +
                   "FROM Bookings b " +
                   "JOIN seats s ON b.FlightID = s.flight_id AND b.SeatNumber = s.seat_number " +
                   "WHERE b.CustomerID = ? AND b.BookingStatus = 'Confirmed'";

    List<Pair<Integer, Class>> flightAndClassList = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
         PreparedStatement preparedStatement = conn.prepareStatement(query)) {

        preparedStatement.setInt(1, customerId);

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int flightId = resultSet.getInt("FlightID");
                String seatClassString = resultSet.getString("class");
                Class seatClass = Class.valueOf(seatClassString); // Assuming Class is your Enum
                flightAndClassList.add(new Pair<>(flightId, seatClass));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle the exception according to your needs
    }

    return flightAndClassList;
}
   
   public boolean ifSaleIdExists(int saleId) {
    boolean exists = false;
    Connection conn = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    try {
        // Replace the connection details with your database information
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");
        
        // Use a PreparedStatement to avoid SQL injection
        String sql = "SELECT COUNT(*) AS count FROM sales WHERE saleid = ?";
        preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setInt(1, saleId);

        resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            int count = resultSet.getInt("count");
            exists = count > 0;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (resultSet != null) resultSet.close();
            if (preparedStatement != null) preparedStatement.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return exists;
}

    public List<Integer> getDistinctYearsFromSales() {
        List<Integer> years = new ArrayList<>();

        // Assuming you have a Connection object (conn) to your database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");) {
            String sql = "SELECT DISTINCT YEAR(transactiondate) AS year FROM sales";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        int year = rs.getInt("year");
                        years.add(year);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }

        return years;
    }
    
    public List<String> getFlightIds() {
        List<String> flightIds = new ArrayList<>();
        String query = "SELECT flightid FROM flights";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    String flightId = resultSet.getString("flightid");
                    flightIds.add(flightId);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your needs
        }

        return flightIds;
    }
    
    public List<String> getAirportNames() {
        List<String> departureAirports = new ArrayList<>();
        String query = "SELECT name FROM airports";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    String airportName = resultSet.getString("name");
                    departureAirports.add(airportName);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your needs
        }

        return departureAirports;
    }


   
    public static void main(String[] args) {
   
    int saleid = 11; 
    int customerID = 1; 
    int flightID = 2; 
    Date transactionDate = Date.valueOf("2023-11-20"); // Replace with an actual date
    double amountpayed = 500.00; // Replace with the actual payment amount
    Method paymentMethod = Method.Cash; // Replace with the desired payment method enum value

    // Call the createPayment method with sample inputs
    Payment p = new Payment();
    int result = p.createPayment(saleid, customerID, flightID, transactionDate, amountpayed, paymentMethod);

    // Check the result of the createPayment method
    if (result == 1) {
        System.out.println("Payment created successfully!");
    } else {
        System.out.println("Failed to create payment. Please check the error messages.");
    }
}

     public int getCustomerId() {
        return customerID;
    }

    public double getAmountPayed(){
        return amountpayed;
    }
    
    public int getSaleID() {
        return saleID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public int getFlightID() {
        return flightID;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public String getTransactionMonth() {
        return transactionMonth;
    }

    public double getTotal() {
        return total;
    }

    public Method getMethod() {
        return method;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public Class getSeatClass() {
        return seatClass;
    }

    public int getTicketsBooked() {
        return ticketsbooked;
    }
  
}