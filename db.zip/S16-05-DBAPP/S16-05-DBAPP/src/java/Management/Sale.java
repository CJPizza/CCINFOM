package Management;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Sale {
    public int saleId;
    public int flightId;
    public int customerId;
    public Date saleDate;
    public double amount;
    public String destination;
    public List<Sale> salesList = new ArrayList<>();

    public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }



    public int loadSalesData(String month, String quarter, String year) {
        Connection conn = connect();
        if (conn == null) {
            return 0; // Connection failed
        }

        try {
            StringBuilder query = new StringBuilder("SELECT * FROM sales");

            // Add conditions for filtering by month, quarter, and year
            if (month != null && !month.isEmpty()) {
                appendWhereClause(query, "MONTH(saleDate) = ?");
            }

            if (quarter != null && !quarter.isEmpty()) {
                appendWhereClause(query, "QUARTER(saleDate) = ?");
            }

            if (year != null && !year.isEmpty()) {
                appendWhereClause(query, "YEAR(saleDate) = ?");
            }

            PreparedStatement pstmt = conn.prepareStatement(query.toString());

            int pIndex = 1;

            // Set parameters based on filters
            if (month != null && !month.isEmpty()) {
                pstmt.setInt(pIndex++, Integer.parseInt(month));
            }

            if (quarter != null && !quarter.isEmpty()) {
                pstmt.setInt(pIndex++, Integer.parseInt(quarter));
            }

            if (year != null && !year.isEmpty()) {
                pstmt.setInt(pIndex++, Integer.parseInt(year));
            }

            ResultSet rs = pstmt.executeQuery();

            salesList.clear();
            while (rs.next()) {
                Sale sale = new Sale();
                sale.saleId = rs.getInt("saleId");
                sale.flightId = rs.getInt("flightId");
                sale.customerId = rs.getInt("customerId");
                sale.saleDate = rs.getDate("saleDate");
                sale.amount = rs.getDouble("amount");
                sale.destination = rs.getString("destination");

                salesList.add(sale);
            }

            rs.close();
            pstmt.close();
            conn.close();
            return 1; // Success
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Failure
        }
    }

    private void appendWhereClause(StringBuilder query, String condition) {
        query.append(query.toString().contains("WHERE") ? " AND" : " WHERE").append(" ").append(condition);
    }


    public static void main(String[] args) {
        try {
            // Example usage or testing code can go here...
            System.out.println("SALES CREATION successful.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
