/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Management;

/**
 *
 * @author ccslearner
 */

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Flight1 {
    public int flightid;
    public String airline;
    public int departureAirport;
    public int arrivalAirport;
    public Date scheduledDepartureTime;
    public Date actualDepartureTime;
    public Date arrivalTime;
    public double ticketPrice;
    public String status;
    public String departureTerminal;
    public String arrivalTerminal;
    public int seats;
    
    public ArrayList<Flight1> flightsList = new ArrayList<>();
    public ArrayList<Integer> availableSeats = new ArrayList<>();
    public ArrayList<String> seatClasses = new ArrayList<>();
   
    public Flight1(){
        // code here if something goes wrong
    }
    
   public static Connection connect(){
        try{
            String username = "root";
            String pass = "Miliye7*";
            String sqlconn= "jdbc:mysql://localhost:3306/hello";
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection(sqlconn, username, pass );
            return conn;
            
            
            
        }catch(Exception e){
             e.printStackTrace();
            return null; // Error occurred
        }
    }
    
    public int createFlight(String airline, int departureAirport, int arrivalAirport, Date scheduledDepartureTime,Date actualDepartureTime, Date arrivalTime, double ticketPrice,
            int seatsAvailable, String status, String departureTerminal, String arrivalTerminal) {
        
        String sql = "INSERT INTO flights (airline, departureairport, arrivalairport, scheduleddeparturetime,actualDepartureTime, arrivaltime, ticketprice, seatsAvailable, status, "
                + "departureterminal, arrivalterminal) VALUES (?, ?, ?, ? ,? , ?, ?, ?, ?, ?, ?)";
        
        String qry = "SELECT MAX(flightid) + 1 AS newID FROM flights";
        int flightid = 0;
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                flightid = rs.getInt("newID");
            }
            
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }

        if (flightid == 0)
            flightid += 1001;
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, airline);
            pstmt.setInt(2, departureAirport);
            pstmt.setInt(3, arrivalAirport);
            pstmt.setDate(4, scheduledDepartureTime);
            pstmt.setDate(5, actualDepartureTime);
            pstmt.setDate(6, arrivalTime);
            pstmt.setDouble(7, ticketPrice);
            pstmt.setInt(8, seatsAvailable);
            pstmt.setString(9, status);
            pstmt.setString(10, departureTerminal);
            pstmt.setString(11, arrivalTerminal);
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Query: " + sql);
            return 0;
        }

        return 1;
    }

    
    
    public int updateFlight(int flightid,String airlinename, int arrivalAirport, Date scheduledDepartureTime, Date actualDepartureTime, Date arrivalTime, double ticketPrice, int seatsAvailable, String status, String departureTerminal, String arrivalTerminal) {
    String sql = "UPDATE flights SET airline=?, arrivalairport=?, scheduleddeparturetime=?, actualdeparturetime=?, arrivaltime=?, ticketprice=?, seatsAvailable=?, status=?,"
            + " departureterminal=?, arrivalterminal=? WHERE flightid=?";
    
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1,airlinename);
        pstmt.setInt(2, arrivalAirport);
        pstmt.setDate(3, scheduledDepartureTime);
        pstmt.setDate(4, actualDepartureTime);
        pstmt.setDate(5, arrivalTime);
        pstmt.setDouble(6, ticketPrice);
        pstmt.setInt(7, seatsAvailable);
        pstmt.setString(8, status);
        pstmt.setString(9, departureTerminal);
        pstmt.setString(10, arrivalTerminal);
        pstmt.setInt(11, flightid);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
    return 1;
}

    
    public int cancelFlight(int flightId) {
        String checkTicketsSql = "SELECT COUNT(*) AS count FROM tickets WHERE flightid = ?";
        
        String checkOnBoardSql = "SELECT COUNT(*) AS count FROM staff_on_flight WHERE flightid = ?";
        
        String sql = "UPDATE flights SET status = 'cancelled' WHERE flightid = ?";
        try (Connection conn = connect();
             PreparedStatement checkTicketsStmt = conn.prepareStatement(checkTicketsSql);
             PreparedStatement checkOnBoardStmt = conn.prepareStatement(checkOnBoardSql))
        {
            checkTicketsStmt.setInt(1, flightId);
            checkOnBoardStmt.setInt(1, flightId);
            
            ResultSet ticketsResult = checkTicketsStmt.executeQuery();
            int ticketsCount = 0;
            if (ticketsResult.next()) {
                ticketsCount = ticketsResult.getInt("count");
            }
            
            ResultSet onBoardResult = checkOnBoardStmt.executeQuery();
            int boardCount = 0;
            if (onBoardResult.next()){
                boardCount = onBoardResult.getInt("count");
            }
            
            if (ticketsCount > 0 || boardCount > 0) {
                return flightId;
            }
            
            String deleteSql = "DELETE FROM flights WHERE flightid = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
                pstmt.setInt(1, flightId);
                pstmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        
        return 1;
    }
    
    public int loadFlight(String airline, int departureAirport, int arrivalAirport,Date scheduledDepartureTime,Date actualDepartureTime,Date arrivalTime,double ticketPrice, int seatsAvailable,
            String status ,String departureTerminal, String arrivalTerminal) {
        Connection conn = connect();
        if (conn == null) {
            return 0; // Connection failed
        }

        try {
            StringBuilder query = new StringBuilder("SELECT f.* FROM flights f ");
            
            System.out.println("");
            System.out.println("Building String");
            System.out.println("");
            
            System.out.println("");
            System.out.println("now checking airline");
            System.out.println("");
            
            
            if(airline != null && !airline.isEmpty()){
                appendWhereClause(query, "(airline LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("airline LIKE " + airline);
            System.out.println("");
            }    
            
            System.out.println("");
            System.out.println("now checking departureAirport");
            System.out.println("");
            
            if(departureAirport > 0){
                appendWhereClause(query,"(departureairport = ? OR ? IS NULL OR ? IS NOT NULL)");
                System.out.println("");
            System.out.println("departure FROM " + departureAirport);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking arrivalAirport");
            System.out.println("");
            
            if(arrivalAirport > 0){
                appendWhereClause(query,"(arrivalairport = ? OR ? IS NULL OR ? IS NOT NULL)");
                System.out.println("");
            System.out.println("arrival TO " + arrivalAirport);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking scheduleddeparturetime");
            System.out.println("");
            
            if(scheduledDepartureTime != null){
                appendWhereClause(query,"(scheduleddeparturetime LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("Scheduled FOR " + scheduledDepartureTime);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking actualAirport");
            System.out.println("");
            
            if (actualDepartureTime != null) {
                appendWhereClause(query, "(actualdeparturetime LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("Left AT " + actualDepartureTime);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking arrivaltime");
            System.out.println("");
            
            if(arrivalTime != null){
                appendWhereClause(query,"(arrivaltime LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("arrived AROUND " + arrivalTime);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking ticketprice");
            System.out.println("");
            
            if(ticketPrice > 0){
                appendWhereClause(query,"(ticketprice = ? OR ? IS NULL OR ? IS NOT NULL)");
                System.out.println("");
            System.out.println("costs ABOUT " + ticketPrice);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking seats");
            System.out.println("");
            
            if(seatsAvailable > 0){
                appendWhereClause(query,"(seatsAvailable = ? OR ? IS NULL OR ? IS NOT NULL)");
                 System.out.println("");
            System.out.println("seats available " + seatsAvailable);
            System.out.println("");
            }
            
            System.out.println("");
            System.out.println("now checking status");
            System.out.println("");
           
            if(status != null && !status.isEmpty()){
                System.out.println("status?");
                appendWhereClause(query, "(status LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("status IS " + status);
            System.out.println("");
            } 
            
            System.out.println("");
            System.out.println("now checking departureterminal");
            System.out.println("");
             
            if(departureTerminal != null && !departureTerminal.isEmpty()){
                appendWhereClause(query, "(departureterminal LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("departs AT " + departureTerminal);
            System.out.println("");
            } 
            
            if(arrivalTerminal != null && !arrivalTerminal.isEmpty()){
                appendWhereClause(query, "(arrivalterminal LIKE ? OR ? IS NULL)");
                System.out.println("");
            System.out.println("arrived TO " + arrivalTerminal);
            System.out.println("");
            } 
            
            System.out.println("");
            System.out.println("now checking arrivalterminal");
            System.out.println("");
            
            PreparedStatement pstmt = conn.prepareStatement(query.toString());

            int pIndex = 0;
            
            if(airline != null && !airline.isEmpty()){
                pstmt.setString(pIndex++, "%" + airline + "%");
                pstmt.setString(pIndex++, "%" + airline + "%");
                System.out.println("");
            System.out.println("airline LIKE " + airline);
            System.out.println("");
            }else{
                pstmt.setString(pIndex++, "%" + airline + "%");
                pstmt.setString(pIndex++, "%" + airline + "%");
            }    
            
            if(departureAirport > 0){
                pstmt.setInt(pIndex++, departureAirport);
                pstmt.setInt(pIndex++, departureAirport);
                pstmt.setInt(pIndex++, departureAirport);
                System.out.println("");
            System.out.println("departure FROM " + departureAirport);
            System.out.println("");
            }else{
                pstmt.setInt(pIndex++, departureAirport);
                pstmt.setInt(pIndex++, departureAirport);
                pstmt.setInt(pIndex++, departureAirport);
            }
            
            if(arrivalAirport > 0){
                pstmt.setInt(pIndex++, arrivalAirport);
                pstmt.setInt(pIndex++, arrivalAirport);
                pstmt.setInt(pIndex++, arrivalAirport);
                System.out.println("");
            System.out.println("arrival TO " + arrivalAirport);
            System.out.println("");
            }else{
                pstmt.setInt(pIndex++, arrivalAirport);
                pstmt.setInt(pIndex++, arrivalAirport);
                pstmt.setInt(pIndex++, arrivalAirport);
            }
            
            if(scheduledDepartureTime != null){
                pstmt.setDate(pIndex++, scheduledDepartureTime);
                pstmt.setDate(pIndex++, scheduledDepartureTime);
                System.out.println("");
            System.out.println("Scheduled FOR " + scheduledDepartureTime);
            System.out.println("");
            }else{
                pstmt.setDate(pIndex++, scheduledDepartureTime);
                pstmt.setDate(pIndex++, scheduledDepartureTime);
            }
            
            if (actualDepartureTime != null) {
                pstmt.setDate(pIndex++, actualDepartureTime);
                pstmt.setDate(pIndex++, actualDepartureTime);
                System.out.println("");
            System.out.println("Left AT " + actualDepartureTime);
            System.out.println("");
            }else{
                pstmt.setDate(pIndex++, actualDepartureTime);
                pstmt.setDate(pIndex++, actualDepartureTime);
            }
            
            if(arrivalTime != null){
                pstmt.setDate(pIndex++, arrivalTime);
                pstmt.setDate(pIndex++, arrivalTime);
                System.out.println("");
            System.out.println("arrived AROUND " + arrivalTime);
            System.out.println("");
            }else{
                pstmt.setDate(pIndex++, arrivalTime);
                pstmt.setDate(pIndex++, arrivalTime);
            }
            
            if(ticketPrice > 0){
                pstmt.setDouble(pIndex++, ticketPrice);
                pstmt.setDouble(pIndex++, ticketPrice);
                pstmt.setDouble(pIndex++, ticketPrice);
                System.out.println("");
            System.out.println("costs ABOUT " + ticketPrice);
            System.out.println("");
            }else{
                pstmt.setDouble(pIndex++, ticketPrice);
                pstmt.setDouble(pIndex++, ticketPrice);
                pstmt.setDouble(pIndex++, ticketPrice);
            }
            
            if(seatsAvailable > 0){
               pstmt.setInt(pIndex++, seatsAvailable);
               pstmt.setInt(pIndex++, seatsAvailable);
               pstmt.setInt(pIndex++, seatsAvailable);
                 System.out.println("");
            System.out.println("seats available " + seatsAvailable);
            System.out.println("");
            }else{
               pstmt.setInt(pIndex++, seatsAvailable);
               pstmt.setInt(pIndex++, seatsAvailable);
               pstmt.setInt(pIndex++, seatsAvailable);
            }
            
            if(status != null && !status.isEmpty()){
                pstmt.setString(pIndex++, "%" + status + "%");
                pstmt.setString(pIndex++, "%" + status + "%");
                System.out.println("");
            System.out.println("status IS " + status);
            System.out.println("");
            }else{
                pstmt.setString(pIndex++, "%" + status + "%");
                pstmt.setString(pIndex++, "%" + status + "%");
            }
            
            if(departureTerminal != null && !departureTerminal.isEmpty()){
                pstmt.setString(pIndex++, "%" + departureTerminal + "%");
                pstmt.setString(pIndex++, "%" + departureTerminal + "%");
                System.out.println("");
            System.out.println("departs AT " + departureTerminal);
            System.out.println("");
            }else{
                pstmt.setString(pIndex++, "%" + departureTerminal + "%");
                pstmt.setString(pIndex++, "%" + departureTerminal + "%");
            }
            
            if(arrivalTerminal != null && !arrivalTerminal.isEmpty()){
                pstmt.setString(pIndex++, "%" + arrivalTerminal + "%");
                pstmt.setString(pIndex++, "%" + arrivalTerminal + "%");
                System.out.println("");
            System.out.println("arrived TO " + arrivalTerminal);
            System.out.println("");
            }else{
                pstmt.setString(pIndex++, "%" + arrivalTerminal + "%");
                pstmt.setString(pIndex++, "%" + arrivalTerminal + "%");
            }
            
            System.out.println("STMT: " + pstmt);
            
            ResultSet rs = pstmt.executeQuery();
            
            flightsList.clear();
            while (rs.next()) {
                Flight1 flight = new Flight1();
                
                System.out.println("");
            System.out.println("adding flight");
            System.out.println("");
                
                // Assuming these are public fields or you have setter methods
                flight.flightid = rs.getInt("flightid");
                flight.airline = rs.getString("airline");
                flight.departureAirport = rs.getInt("departureairport");
                flight.arrivalAirport = rs.getInt("arrivalairport");
                flight.scheduledDepartureTime = rs.getDate("scheduleddeparturetime");
                flight.actualDepartureTime = rs.getDate("actualDepartureTime");
                flight.arrivalTime = rs.getDate("arrivaltime");
                flight.ticketPrice = rs.getDouble("ticketprice");
                flight.status = rs.getString("status");
                flight.departureTerminal = rs.getString("departureterminal");
                flight.arrivalTerminal = rs.getString("arrivalterminal");
                flightsList.add(flight);
                
                System.out.println("");
            System.out.println("flight added");
            System.out.println("");
            }
            rs.close();
            pstmt.close();
            conn.close();
            return 1; // Successfully loaded
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Error occurred
        }
    } 
    
    public int loadFlight(int flightId) {
        Connection conn = connect();
        if (conn == null) {
            return 0; // Connection failed
        }

        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM flights WHERE flightid = ?");
            pstmt.setInt(1,flightId);
                      
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Flight1 flight = new Flight1();
                // Assuming these are public fields or you have setter methods
                flight.flightid = rs.getInt("flightid");
                flight.airline = rs.getString("airline");
                flight.departureAirport = rs.getInt("departureairport");
                flight.arrivalAirport = rs.getInt("arrivalairport");
                flight.scheduledDepartureTime = rs.getDate("scheduleddeparturetime");
                flight.actualDepartureTime = rs.getDate("actualDepartueTime");
                flight.arrivalTime = rs.getDate("arrivaltime");
                flight.ticketPrice = rs.getDouble("ticketprice");
                flight.status = rs.getString("status");
                flight.departureTerminal = rs.getString("departureterminal");
                flight.arrivalTerminal = rs.getString("arrivalterminal");
                flightsList.add(flight);
            }
            rs.close();
            pstmt.close();
            conn.close();
            return 1; // Successfully loaded
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return 0; // Error occurred
        }
    } 
    
    public int createSeats(int seatsAvailable, int eccSeats, int busSeats, int firSeats){
        
        System.out.println("");
        System.out.println("seatsAvailable = " + seatsAvailable + " eccSeats = " + eccSeats + " buSeats = " + busSeats + " firSeats = " + firSeats);
        System.out.println("");
        
        availableSeats.clear();
        seatClasses.clear();
        for(int i = 0;i < seatsAvailable;i++){
            availableSeats.add(i);
        }
        
        System.out.println("");
        System.out.println("availableSeats created");
        System.out.println("");
        
        for(int i = 0;i < eccSeats;i++){
            seatClasses.add("Economy");
        }
        
        System.out.println("");
        System.out.println("economy created");
        System.out.println("");
        
        for(int i = 0;i < busSeats;i++){
            seatClasses.add("Business");
        }
        
        System.out.println("");
        System.out.println("business created");
        System.out.println("");
        
        for(int i = 0;i < firSeats;i++){
            seatClasses.add("First");
        }
        
        System.out.println("");
        System.out.println("first created");
        System.out.println("");
        
        String sql = "INSERT INTO seats (flight_id,seat_number,seat_class,status) VALUES (?, ?, ?, ?)";
        
        String qry = "SELECT MAX(flightid) AS newID FROM flights";
        
        int flightid = 0;
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                flightid = rs.getInt("newID");
            }
            
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }

        if (flightid == 0)
            flightid += 1001;
        
        System.out.println("");
        System.out.println("flightid = " + flightid);
        System.out.println("");
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            for(int i = 0;i < seatsAvailable;i++){
                pstmt.setInt(1,flightid);
                pstmt.setString(2,String.valueOf(availableSeats.get(i)));
                pstmt.setString(3,seatClasses.get(i));
                pstmt.setString(4,"free");
                pstmt.executeUpdate();
                System.out.println("seat created");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Query: " + sql);
            return 0;
        }

        System.out.println("");
        System.out.println("done");
        System.out.println("");
        
        return 1;
 
    }
    
    public int updateSeats(int flightid, String seatNumber, String seatClass, String status) {
    String sql = "UPDATE seats SET seat_class=?, status=? WHERE flight_id=? AND seat_number=?";

    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, seatClass);
        pstmt.setString(2, status);
        pstmt.setInt(3, flightid);
        pstmt.setString(4, seatNumber);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
    return 1;

}
    
    public int addSeats(int flightid,int newSeats, int eccSeats,int busSeats, int firSeats){
        String sql = "INSERT INTO seats (flight_id,seat_number,seat_class,status) VALUES (?,?,?,?)";
        
        String qry = "SELECT MAX(CAST(seat_number AS UNSIGNED)) AS newID FROM seats WHERE flight_id = ?"; 
        
        String seatno = "0";
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                seatno = rs.getString("newID");
            }
            
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }
        
        availableSeats.clear();
        seatClasses.clear();
        
        int x = Integer.parseInt(seatno);
        for(int i = 0;i < newSeats;i++){            
            availableSeats.add(x);
            x++;
        }
        
        for(int i = 0;i < eccSeats;i++){
            seatClasses.add("Economy");
        }
        
        for(int i = 0;i < busSeats;i++){
            seatClasses.add("Business");
        }
        
        for(int i = 0;i < firSeats;i++){
            seatClasses.add("First Class");
        }
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            for(int i = 0;i < newSeats;i++){
                pstmt.setInt(1,flightid);
                pstmt.setString(2,String.valueOf(availableSeats.get(i)));
                pstmt.setString(3,seatClasses.get(i));
                pstmt.setString(4,"free");
                pstmt.executeUpdate();
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Query: " + sql);
            return 0;
        }
        
        return 1;
    }
    
    public int deleteSeats(int flightId){
        String checkTicketsSql = "SELECT COUNT(*) AS count FROM tickets WHERE flightid = ?";//AND seat_number = ?
        
        String qry = "SELECT MAX(CAST(seat_number AS UNSIGNED)) AS newID FROM seats WHERE flight_id = ?"; 
        
        String seatno = "0";
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                seatno = rs.getString("newID");
            }
            
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }
        
        try (Connection conn = connect();
             PreparedStatement checkTicketsStmt = conn.prepareStatement(checkTicketsSql))
        {
            checkTicketsStmt.setInt(1, flightId);
            
            ResultSet ticketsResult = checkTicketsStmt.executeQuery();
            int ticketsCount = 0;
            if (ticketsResult.next()) {
                ticketsCount = ticketsResult.getInt("count");
            }
            
            if (ticketsCount > 0) {
                return flightId;
            }
                        
            String deleteSql = "DELETE FROM seats WHERE flight_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
                int x = Integer.parseInt(seatno);
                for(int i = 0;i < x;i++){
                    pstmt.setInt(1,flightId);
                    pstmt.executeUpdate();
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        
        return 1;
    }
    
    public int removeSeats(int flightId, int negSeats){
        //remember to finish checking code so that it checks the seat number in tickets
        
        String checkTicketsSql = "SELECT COUNT(*) AS count FROM tickets WHERE flightid = ?";//AND seat_number = ?
        
        String qry = "SELECT MAX(CAST(seat_number AS UNSIGNED)) AS newID FROM seats WHERE flight_id = ?"; 
        
        String seatno = "0";
        
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(qry)) {

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                seatno = rs.getString("newID");
            }
            
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0; // Error occurred
        }
        
        try (Connection conn = connect();
             PreparedStatement checkTicketsStmt = conn.prepareStatement(checkTicketsSql))
        {
            checkTicketsStmt.setInt(1, flightId);
            
            ResultSet ticketsResult = checkTicketsStmt.executeQuery();
            int ticketsCount = 0;
            if (ticketsResult.next()) {
                ticketsCount = ticketsResult.getInt("count");
            }
            
            if (ticketsCount > 0) {
                return flightId;
            }
                        
            String deleteSql = "DELETE FROM seats WHERE seat_number = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
                int x = Integer.parseInt(seatno);
                for(int i = 0;i < negSeats;i++){
                    pstmt.setInt(1,x);
                    pstmt.executeUpdate();
                    x--;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        
        return 1;
    }
    
    public int loadSeats(int flightid) {
    String sqlRowCount = "SELECT COUNT(*) AS rowCount FROM seats WHERE flight_id = ?";

    int rowCount = 0;

    try (Connection conn = connect();
         PreparedStatement pstmtRowCount = conn.prepareStatement(sqlRowCount)) {
        pstmtRowCount.setInt(1, flightid);

        try (ResultSet rsRowCount = pstmtRowCount.executeQuery()) {
            if (rsRowCount.next()) {
                rowCount = rsRowCount.getInt("rowCount");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }

    String sqlRetrieveSeats = "SELECT seat_number, seat_class FROM seats WHERE flight_id = ?";
    try (Connection conn = connect();
         PreparedStatement pstmtRetrieveSeats = conn.prepareStatement(sqlRetrieveSeats)) {
            pstmtRetrieveSeats.setInt(1, flightid);

        try (ResultSet rsRetrieveSeats = pstmtRetrieveSeats.executeQuery()) {
            while (rsRetrieveSeats.next()) {
                String retrievedSeatNumber = rsRetrieveSeats.getString("seat_number");
                String retrievedSeatClass = rsRetrieveSeats.getString("seat_class");

                availableSeats.add(Integer.parseInt(retrievedSeatNumber));
                seatClasses.add(retrievedSeatClass);
                
                System.out.println("A seat added");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }

    System.out.println("Seats loaded");
    return rowCount;
}

    
    private void appendWhereClause(StringBuilder query, String condition) {
        query.append(query.toString().contains("WHERE") ? " AND" : " WHERE").append(" ").append(condition);
    }
    
    public int getLowestSeatID(){
        String sql = "SELECT MIN(flight_id) AS min_value FROM seats";
        
        int minValue = 0;
    
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery()) {

        if (rs.next()) {
            minValue = rs.getInt("min_value");

            System.out.println("Minimum value: " + minValue);
        }

        } catch (SQLException e) {
            e.printStackTrace();
   
        }
        return minValue;
    }
    
    public int getHighestSeatID(){
        String sql = "SELECT MAX(flight_id) AS max_value FROM seats";
        
        int maxValue = 0;
    
        try (Connection conn = connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery()) {

        if (rs.next()) {
            maxValue = rs.getInt("max_value");

            System.out.println("Maximum value: " + maxValue);
        }

        } catch (SQLException e) {
            e.printStackTrace();
   
        }
        return maxValue;
    }
    
    public void emptySeatArrays(){
        availableSeats.clear();
        seatClasses.clear();
    }
    
    public List<Integer> getDistinctYearsFromFlights() {
        List<Integer> years = new ArrayList<>();

        // Assuming you have a Connection object (conn) to your database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hello?useTimezone=true&serverTimezone=UTC&user=root&password=12345678");) {
            String sql = "SELECT DISTINCT YEAR(arrivaltime) AS year FROM flights";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        int year = rs.getInt("year");
                        years.add(year);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your application's requirements
        }

        return years;
    }
    
    public List<String> getFlightIds() {
        List<String> flightIds = new ArrayList<>();
        String query = "SELECT flightid FROM flights";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    String flightId = resultSet.getString("flightid");
                    flightIds.add(flightId);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your needs
        }

        return flightIds;
    }
    
     public List<String> getAirportNames() {
        List<String> departureAirports = new ArrayList<>();
        String query = "SELECT name FROM airports";

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            try (ResultSet resultSet = pstmt.executeQuery()) {
                while (resultSet.next()) {
                    String airportName = resultSet.getString("name");
                    departureAirports.add(airportName);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception according to your needs
        }

        return departureAirports;
    }
     
    public int getAirportIdByName(String airportName) {
    String sql = "SELECT airportcode FROM airports WHERE airportname = ?";
    
    try (Connection conn = connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, airportName);
        
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("airportcode");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return 0;
    }
    return 1;
}
    public List<Flight1> getFlightsByOnTime(String selectedMonth, String selectedQuarter, String enteredYear) {
    List<Flight1> flights = new ArrayList<>();

    try {
        // Construct the base query to retrieve flights where scheduleddeparturetime = actualdeparturetime
        String query = "SELECT * FROM flights WHERE scheduleddeparturetime = actualdeparturetime";

        // Add conditions for month, quarter, and year if provided
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            query += " AND MONTH(scheduleddeparturetime) = ?";
        }

        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            query += " AND (QUARTER(scheduleddeparturetime) = ? "
                    + "OR (MONTH(scheduleddeparturetime) >= 1 "
                    + "AND MONTH(scheduleddeparturetime) <= 3 "
                    + "AND ? = 'q1') OR (MONTH(scheduleddeparturetime) >= 4 "
                    + "AND MONTH(scheduleddeparturetime) <= 6 "
                    + "AND ? = 'q2') OR (MONTH(scheduleddeparturetime) >= 7 "
                    + "AND MONTH(scheduleddeparturetime) <= 9 AND ? = 'q3') "
                    + "OR (MONTH(scheduleddeparturetime) >= 10 "
                    + "AND MONTH(scheduleddeparturetime) <= 12 "
                    + "AND ? = 'q4')) ";
        }

        if (enteredYear != null && !enteredYear.isEmpty()) {
            query += " AND YEAR(scheduleddeparturetime) = ?";
        }

        Connection conn = connect();
        if (conn == null) {
            return null; // Connection failed
        }

        PreparedStatement pstmt = conn.prepareStatement(query);

        // Set parameters based on the provided values
        int paramIndex = 1;
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            pstmt.setString(paramIndex++, selectedMonth);
        }
        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            for (int i = 0; i <= 4; i++) {
                pstmt.setString(paramIndex++, selectedQuarter);
            }
        }
        if (enteredYear != null && !enteredYear.isEmpty()) {
            pstmt.setString(paramIndex, enteredYear);
        }

        System.out.println("query is now " + query);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            int flightId = rs.getInt("flightid");
            // Retrieve other fields as needed
            String airline = rs.getString("airline");
            int departureAirport = rs.getInt("departureairport");
            int arrivalAirport = rs.getInt("arrivalairport");
            Date scheduleddeparturetime = rs.getDate("scheduleddeparturetime");
            Date actualdeparturetime = rs.getDate("actualdeparturetime");
            Date arrivaltime = rs.getDate("arrivaltime");
            double ticketprice = rs.getDouble("ticketprice");
            int seatsAvailable = rs.getInt("seatsAvailable");
            String status = rs.getString("status");
            String departureTerminal = rs.getString("departureterminal");
            String arrivalTerminal = rs.getString("arrivalterminal");
            
            // Create a Flight object and set its properties
            Flight1 flight = new Flight1();
            flight.flightid = flightId;
            flight.airline = airline;
            flight.departureAirport = departureAirport;
            flight.arrivalAirport = arrivalAirport;
            flight.scheduledDepartureTime = scheduleddeparturetime;
            flight.actualDepartureTime = actualdeparturetime;
            flight.arrivalTime = arrivaltime;
            flight.ticketPrice = ticketprice;
            flight.seats = seatsAvailable;
            flight.status = status;
            flight.departureTerminal = departureTerminal;
            flight.arrivalTerminal = arrivalTerminal;

            flights.add(flight);
        }

        rs.close();
        pstmt.close();
        conn.close();

    } catch (SQLException e) {
        e.printStackTrace();
        return null;
    }

    return flights;
}
    
    public List<Flight1> getFlightsByDelayed(String selectedMonth, String selectedQuarter, String enteredYear) {
    List<Flight1> flights = new ArrayList<>();

    try {
        // Construct the base query to retrieve flights where scheduleddeparturetime = actualdeparturetime
        String query = "SELECT * FROM flights WHERE scheduleddeparturetime < actualdeparturetime";

        // Add conditions for month, quarter, and year if provided
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            query += " AND MONTH(scheduleddeparturetime) = ?";
        }

        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            query += " AND (QUARTER(scheduleddeparturetime) = ? "
                    + "OR (MONTH(scheduleddeparturetime) >= 1 "
                    + "AND MONTH(scheduleddeparturetime) <= 3 "
                    + "AND ? = 'q1') OR (MONTH(scheduleddeparturetime) >= 4 "
                    + "AND MONTH(scheduleddeparturetime) <= 6 "
                    + "AND ? = 'q2') OR (MONTH(scheduleddeparturetime) >= 7 "
                    + "AND MONTH(scheduleddeparturetime) <= 9 AND ? = 'q3') "
                    + "OR (MONTH(scheduleddeparturetime) >= 10 "
                    + "AND MONTH(scheduleddeparturetime) <= 12 "
                    + "AND ? = 'q4')) ";
        }

        if (enteredYear != null && !enteredYear.isEmpty()) {
            query += " AND YEAR(scheduleddeparturetime) = ?";
        }

        System.out.println("query is now " + query);
        Connection conn = connect();
        if (conn == null) {
            return null; // Connection failed
        }

        PreparedStatement pstmt = conn.prepareStatement(query);

        // Set parameters based on the provided values
        int paramIndex = 1;
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            pstmt.setString(paramIndex++, selectedMonth);
        }
        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            for (int i = 0; i <= 4; i++) {
                pstmt.setString(paramIndex++, selectedQuarter);
            }
        }
        if (enteredYear != null && !enteredYear.isEmpty()) {
            pstmt.setString(paramIndex, enteredYear);
        }

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            int flightId = rs.getInt("flightid");
            // Retrieve other fields as needed
            String airline = rs.getString("airline");
            int departureAirport = rs.getInt("departureairport");
            int arrivalAirport = rs.getInt("arrivalairport");
            Date scheduleddeparturetime = rs.getDate("scheduleddeparturetime");
            Date actualdeparturetime = rs.getDate("actualdeparturetime");
            Date arrivaltime = rs.getDate("arrivaltime");
            double ticketprice = rs.getDouble("ticketprice");
            int seatsAvailable = rs.getInt("seatsAvailable");
            String status = rs.getString("status");
            String departureTerminal = rs.getString("departureterminal");
            String arrivalTerminal = rs.getString("arrivalterminal");
            
            // Create a Flight object and set its properties
            Flight1 flight = new Flight1();
            flight.flightid = flightId;
            flight.airline = airline;
            flight.departureAirport = departureAirport;
            flight.arrivalAirport = arrivalAirport;
            flight.scheduledDepartureTime = scheduleddeparturetime;
            flight.actualDepartureTime = actualdeparturetime;
            flight.arrivalTime = arrivaltime;
            flight.ticketPrice = ticketprice;
            flight.seats = seatsAvailable;
            flight.status = status;
            flight.departureTerminal = departureTerminal;
            flight.arrivalTerminal = arrivalTerminal;

            flights.add(flight);
        }

        rs.close();
        pstmt.close();
        conn.close();

    } catch (SQLException e) {
        e.printStackTrace();
        return null;
    }

    return flights;
}
    
    public List<Flight1> getFlightsByCanceled(String selectedMonth, String selectedQuarter, String enteredYear) {
    List<Flight1> flights = new ArrayList<>();

    try {
        // Construct the base query to retrieve flights where scheduleddeparturetime = actualdeparturetime
        String query = "SELECT * FROM flights WHERE status LIKE %canceled%";

        // Add conditions for month, quarter, and year if provided
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            query += " AND MONTH(scheduleddeparturetime) = ?";
        }

        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            query += " AND (QUARTER(scheduleddeparturetime) = ? "
                    + "OR (MONTH(scheduleddeparturetime) >= 1 "
                    + "AND MONTH(scheduleddeparturetime) <= 3 "
                    + "AND ? = 'q1') OR (MONTH(scheduleddeparturetime) >= 4 "
                    + "AND MONTH(scheduleddeparturetime) <= 6 "
                    + "AND ? = 'q2') OR (MONTH(scheduleddeparturetime) >= 7 "
                    + "AND MONTH(scheduleddeparturetime) <= 9 AND ? = 'q3') "
                    + "OR (MONTH(scheduleddeparturetime) >= 10 "
                    + "AND MONTH(scheduleddeparturetime) <= 12 "
                    + "AND ? = 'q4')) ";
        }

        if (enteredYear != null && !enteredYear.isEmpty()) {
            query += " AND YEAR(scheduleddeparturetime) = ?";
        }

        Connection conn = connect();
        if (conn == null) {
            return null; // Connection failed
        }

        System.out.println("query is now " + query);
        PreparedStatement pstmt = conn.prepareStatement(query);

        // Set parameters based on the provided values
        int paramIndex = 1;
        if (selectedMonth != null && !selectedMonth.isEmpty()) {
            pstmt.setString(paramIndex++, selectedMonth);
        }
        if (selectedQuarter != null && !selectedQuarter.isEmpty()) {
            for (int i = 0; i <= 4; i++) {
                pstmt.setString(paramIndex++, selectedQuarter);
            }
        }
        if (enteredYear != null && !enteredYear.isEmpty()) {
            pstmt.setString(paramIndex, enteredYear);
        }

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            int flightId = rs.getInt("flightid");
            // Retrieve other fields as needed
            String airline = rs.getString("airline");
            int departureAirport = rs.getInt("departureairport");
            int arrivalAirport = rs.getInt("arrivalairport");
            Date scheduleddeparturetime = rs.getDate("scheduleddeparturetime");
            Date actualdeparturetime = rs.getDate("actualdeparturetime");
            Date arrivaltime = rs.getDate("arrivaltime");
            double ticketprice = rs.getDouble("ticketprice");
            int seatsAvailable = rs.getInt("seatsAvailable");
            String status = rs.getString("status");
            String departureTerminal = rs.getString("departureterminal");
            String arrivalTerminal = rs.getString("arrivalterminal");
            
            // Create a Flight object and set its properties
            Flight1 flight = new Flight1();
            flight.flightid = flightId;
            flight.airline = airline;
            flight.departureAirport = departureAirport;
            flight.arrivalAirport = arrivalAirport;
            flight.scheduledDepartureTime = scheduleddeparturetime;
            flight.actualDepartureTime = actualdeparturetime;
            flight.arrivalTime = arrivaltime;
            flight.ticketPrice = ticketprice;
            flight.seats = seatsAvailable;
            flight.status = status;
            flight.departureTerminal = departureTerminal;
            flight.arrivalTerminal = arrivalTerminal;

            flights.add(flight);
        }

        rs.close();
        pstmt.close();
        conn.close();

    } catch (SQLException e) {
        e.printStackTrace();
        return null;
    }

    return flights;
}


}
