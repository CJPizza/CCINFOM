drop database hello;
create database hello;
use hello;


CREATE TABLE Countries (
    country_id INT AUTO_INCREMENT PRIMARY KEY,
    country_name VARCHAR(255)
);

CREATE TABLE Cities (
    city_id INT AUTO_INCREMENT PRIMARY KEY,
    city_name VARCHAR(255),
    country_id INT,
    FOREIGN KEY (country_id) REFERENCES Countries(country_id)
);

CREATE TABLE PostalCodes (
    postalcode INT AUTO_INCREMENT PRIMARY KEY,
    postal_code INT,
    city_id INT,
    FOREIGN KEY (city_id) REFERENCES Cities(city_id)
);

CREATE TABLE airports (
    airportid INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    city_id INT,
    postalcode INT,
    date_established DATE,
    airport_website VARCHAR(255),
    unique(city_id),
     FOREIGN KEY (city_id) REFERENCES Cities(city_id),
    FOREIGN KEY (postalcode) REFERENCES PostalCodes(postalcode)
);

CREATE TABLE terminals (
    terminalid INT AUTO_INCREMENT PRIMARY KEY,
    airportid INT,
    terminal_number INT,
    UNIQUE (airportid, terminal_number),
    FOREIGN KEY (airportid) REFERENCES airports(airportid)
    ON DELETE SET NULL 
	
);

CREATE TABLE flights (
    flightid INT AUTO_INCREMENT PRIMARY KEY,
    airline VARCHAR(255),
    departureairport INT,
    arrivalairport INT,
    scheduleddeparturetime DATE,
    actualdeparturetime DATE,
    arrivaltime DATE,
    ticketprice DECIMAL(10, 2),
    status ENUM('scheduled', 'boarding', 'inair', 'landed', 'canceled'),
    departureterminal INT,
    arrivalterminal INT,
    seatsAvailable INT,
    FOREIGN KEY (departureairport) REFERENCES airports(airportid) ON DELETE SET NULL,
    FOREIGN KEY (arrivalairport) REFERENCES airports(airportid)	ON DELETE SET NULL,
    FOREIGN KEY (departureterminal) REFERENCES terminals(terminalid) ON DELETE SET NULL,
    FOREIGN KEY (arrivalterminal) REFERENCES terminals(terminalid) ON DELETE SET NULL
);

CREATE TABLE seats (
    flight_id INT,
    seat_number VARCHAR(10),
    class ENUM('Economy','Business','First'),
    status ENUM('taken', 'free'),
    PRIMARY KEY (flight_id, seat_number),
    FOREIGN KEY (flight_id) REFERENCES flights(flightid)
);


CREATE TABLE customers (
    customerid INT PRIMARY KEY,
    completename_first VARCHAR(45),
    completename_last VARCHAR(45),
    completename_middle VARCHAR(45),
    phone BIGINT(11),
    city_id INT,
    postalcode_id INT,
    dateofbirth DATE,
    sex ENUM('FEMALE', 'MALE'),
    specialneeds ENUM('Y', 'N'),
    FOREIGN KEY (postalcode_id) REFERENCES PostalCodes(postalcode)
);


CREATE TABLE Bookings (
    BookingID INT PRIMARY KEY AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    FlightID INT,
    SeatNumber VARCHAR(10),
    BookingDate DATE,
    Bags INT,
    BookingStatus ENUM('Pending','Confirmed', 'Cancelled'),
    CHBStatus ENUM('Checked-in', 'Boarded', 'Not checked-in', 'Cancelled'),
    FOREIGN KEY (CustomerID) REFERENCES customers(customerid),
    FOREIGN KEY (FlightID) REFERENCES flights(flightid),
    FOREIGN KEY (FlightID, SeatNumber) REFERENCES seats(flight_id, seat_number)
);

CREATE TABLE airlinestaffrecords ( -- 18 attributes
	-- staff info
    staffid INT(4)PRIMARY KEY, 
    firstname VARCHAR(45),
    lastname VARCHAR(45),
    middlename VARCHAR(45),
    contactnumber BIGINT(11),
    dateofbirth DATE,
    sex ENUM('FEMALE', 'MALE'),
    -- staff address
    postalcode_id INT,
    -- staff professional
    job VARCHAR(45),
    salary DECIMAL(10, 2),
    performance ENUM('EXCELLENT', 'GREAT', 'GOOD', 'NEEDS WORK') NOT NULL,
    emrgencycontactperson VARCHAR(45), -- added
    emrgencyphone BIGINT(11),
    flightid INT, -- for shifts
    
    FOREIGN KEY (flightid) REFERENCES flights(flightid),
    FOREIGN KEY (postalcode_id) REFERENCES PostalCodes(postalcode)
);


CREATE TABLE sales (
    saleid INT PRIMARY KEY,
    customerid INT,
    flightid INT,
    transactiondate DATE,
    transactionmonth VARCHAR(10),
    amountpayed double, -- total amount of payments made
    total DECIMAL(8, 2), -- amount of all tickets
    method ENUM('Cash', 'CreditCard', 'DebitCard', 'Other'),
    status ENUM('Canceled', 'Pending', 'Completed'),
    ticketsbooked INT(2), -- total amount of orders
    FOREIGN KEY (customerid) REFERENCES customers(customerid),
    FOREIGN KEY (flightid) REFERENCES flights(flightid)
);

INSERT INTO Countries (country_name) VALUES 
    ('United States'), 
    ('France'), 
    ('Japan'), 
    ('United Kingdom'), 
    ('Philippines'),
    ('Brazil'),
    ('Spain'),
    ('Italy'),
    ('Canada'),
    ('Mexico'),
    ('Taiwan'),
    ('South Korea'),
    ('India'),
    ('Russia'),
    ('Egypt'),
    ('South Africa'),
    ('Nigeria');



-- Adding cities for United States (country_id = 1)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Chicago', 1), 
    ('San Francisco', 1), 
    ('Miami', 1);

-- Adding cities for France (country_id = 2)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Marseille', 2), 
    ('Lyon', 2), 
    ('Nice', 2);

-- Adding cities for Japan (country_id = 3)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Kyoto', 3), 
    ('Sapporo', 3), 
    ('Nagoya', 3);

-- Adding cities for United Kingdom (country_id = 4)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Manchester', 4), 
    ('Birmingham', 4), 
    ('Glasgow', 4);

-- Adding cities for Philippines (country_id = 5)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Cebu', 5), 
    ('Davao', 5), 
    ('Iloilo', 5);

-- Adding cities for Brazil (country_id = 6)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Sao Paulo', 6), 
    ('Rio de Janeiro', 6), 
    ('Salvador', 6);

-- Adding cities for Spain (country_id = 7)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Valencia', 7), 
    ('Seville', 7), 
    ('Bilbao', 7);

-- Adding cities for Italy (country_id = 8
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Naples', 8), 
    ('Turin', 8), 
    ('Palermo', 8);

-- Adding cities for Canada (country_id = 9)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Montreal', 9), 
    ('Calgary', 9), 
    ('Ottawa', 9);

-- Adding cities for Mexico (country_id = 10)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Guadalajara', 10), 
    ('Monterrey', 10), 
    ('Puebla', 10);

-- Adding cities for Taiwan (country_id = 11)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Kaohsiung', 11), 
    ('Taichung', 11), 
    ('Tainan', 11);

-- Adding cities for South Korea (country_id = 12)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Incheon', 12), 
    ('Daegu', 12), 
    ('Gwangju', 12);

-- Adding cities for India (country_id = 13)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Bangalore', 13), 
    ('Hyderabad', 13), 
    ('Ahmedabad', 13);

-- Adding cities for Russia (country_id = 14)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Novosibirsk', 14), 
    ('Yekaterinburg', 14), 
    ('Nizhny Novgorod', 14);

-- Adding cities for Egypt (country_id = 15)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Giza', 15), 
    ('Alexandria', 15), 
    ('Luxor', 15);

-- Adding cities for South Africa (country_id = 16)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Durban', 16), 
    ('Pretoria', 16), 
    ('Port Elizabeth', 16);

-- Adding cities for Nigeria (country_id = 17)
INSERT INTO Cities (city_name, country_id) VALUES 
    ('Ibadan', 17), 
    ('Port Harcourt', 17), 
    ('Benin City', 17);    


-- Adding postal codes for new cities in United States
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('60601', 1),   -- Chicago
    ('94102', 2),   -- San Francisco
    ('33101', 3);   -- Miami

-- Adding postal codes for new cities in France
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('13001', 4),   -- Marseille
    ('69001', 5),   -- Lyon
    ('06000', 6);   -- Nice

-- Adding postal codes for new cities in Japan
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('6008216', 7),  -- Kyoto
    ('0600042', 8),  -- Sapporo
    ('4500002', 9);  -- Nagoya

-- Adding postal codes for new cities in United Kingdom
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('120412', 10),  -- Manchester
    ('312012', 11),  -- Birmingham
    ('200012', 12);  -- Glasgow

-- Adding postal codes for new cities in Philippines
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('6000', 13),   -- Cebu
    ('8000', 14),   -- Davao
    ('5000', 15);   -- Iloilo

-- Adding postal codes for new cities in Brazil
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('01000000', 16),  -- Sao Paulo
    ('20000000', 17),  -- Rio de Janeiro
    ('40000000', 18);  -- Salvador

-- Adding postal codes for new cities in Spain
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('46001', 19),  -- Valencia
    ('41001', 20),  -- Seville
    ('48001', 21);  -- Bilbao

-- Adding postal codes for new cities in Italy
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('80100', 22),  -- Naples
    ('10121', 23),  -- Turin
    ('90100', 24);  -- Palermo

-- Adding postal codes for new cities in Canada
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('100231', 25),  -- Montreal
    ('20050', 26),  -- Calgary
    ('600212', 27);  -- Ottawa

-- Adding postal codes for new cities in Mexico
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('44100', 28),  -- Guadalajara
    ('64000', 29),  -- Monterrey
    ('72000', 30);  -- Puebla

-- Adding postal codes for new cities in Taiwan
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('800', 31),   -- Kaohsiung
    ('400', 32),   -- Taichung
    ('700', 33);   -- Tainan

-- Adding postal codes for new cities in South Korea
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('22382', 34),  -- Incheon
    ('41566', 35),  -- Daegu
    ('61473', 36);  -- Gwangju

-- Adding postal codes for new cities in India
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('560001', 37),  -- Bangalore
    ('500001', 38),  -- Hyderabad
    ('380001', 39);  -- Ahmedabad

-- Adding postal codes for new cities in Russia
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('630000', 40),  -- Novosibirsk
    ('620000', 41),  -- Yekaterinburg
    ('603000', 42);  -- Nizhny Novgorod

-- Adding postal codes for new cities in Egypt
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('12556', 43),  -- Giza
    ('21599', 44),  -- Alexandria
    ('85951', 45);  -- Luxor

-- Adding postal codes for new cities in South Africa
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('4001', 46),   -- Durban
    ('0002', 47),   -- Pretoria
    ('6001', 48);   -- Port Elizabeth

-- Adding postal codes for new cities in Nigeria
INSERT INTO PostalCodes (postal_code, city_id) VALUES 
    ('200001', 49),  -- Ibadan
    ('500001', 50),  -- Port Harcourt
    ('300001', 51);  -- Benin City

INSERT INTO airports (name, city_id, postalcode, date_established, airport_website)
VALUES
    ('Hare International Airport', 1, 1, '1944-02-01', 'http://www.flychicago.com/OHare'),
    ('San Francisco International Airport', 2, 2, '1927-05-07', 'http://www.flysfo.com'),
    ('Miami International Airport', 3, 3, '1928-09-15', 'http://www.miami-airport.com'),
    ('Marseille Provence Airport', 4, 4, '1922-10-24', 'http://www.marseille-airport.com'),
    ('Lyon–Saint Exupéry Airport', 5, 5, '1975-04-12', 'http://www.lyonaeroports.com'),
    ('Nice Côte dAzur Airport', 6, 6, '1944-07-16', 'http://en.nice.aeroport.fr'),
    ('Kansai International Airport', 7, 7, '1994-09-04', 'http://www.kansai-airport.or.jp'),
    ('New Chitose Airport', 8, 8, '1988-07-20', 'http://www.new-chitose-airport.jp'),
    ('Chubu Centrair International Airport', 9, 9, '2005-02-17', 'http://www.centrair.jp'),
    ('Manchester Airport', 10, 10, '1938-06-25', 'http://www.manchesterairport.co.uk'),
    ('Birmingham Airport', 11, 11, '1939-07-08', 'http://www.birminghamairport.co.uk'),
    ('Glasgow Airport', 12, 12, '1966-05-02', 'http://www.glasgowairport.com'),
    ('Mactan-Cebu International Airport', 13, 13, '1960-08-12', 'http://www.mciaa.gov.ph'),
    ('Francisco Bangoy International Airport', 14, 14, '1941-12-26', 'http://www.davaoairport.com'),
    ('Iloilo International Airport', 15, 15, '2007-06-14', 'http://www.iloiloairport.com'),
    ('São Paulo–Guarulhos International Airport', 16, 16, '1985-01-20', 'http://www.gru.com.br'),
    ('Rio de Janeiro–Galeão International Airport', 17, 17, '1952-01-10', 'http://www.riogaleao.com'),
    ('Deputado Luís Eduardo Magalhães International Airport', 18, 18, '1925-03-18', 'http://www.salvador-airport.com.br'),
    ('Valencia Airport', 19, 19, '1933-09-01', 'http://www.aena.es/en/valencia-airport/index.html'),
    ('Seville Airport', 20, 20, '1915-06-06', 'http://www.aena.es/en/seville-airport/index.html');


INSERT INTO terminals (airportid, terminal_number) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 1),
(5, 1),
(2, 1),
(3, 2),
(3, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 3),
(3, 4),
(4, 2),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 3),
(8, 1),
(8, 2),
(9, 3),
(10, 1),
(11, 2),
(12, 3),
(12, 2),
(13, 1),
(14, 2),
(15, 3),
(16, 2),
(17, 1),
(18, 3),
(19, 3),
(20, 1),
(20, 2),
(18, 4),
(18, 1),
(18, 2),
(12, 1),
(17, 2),
(17, 3),
(17, 4),
(18, 5);

INSERT INTO flights (airline, departureairport, arrivalairport, scheduleddeparturetime, actualdeparturetime, arrivaltime, ticketprice, status, departureterminal, arrivalterminal) VALUES 
    ('Delta Airlines', 1, 2, '2023-01-15', '2023-01-15 12:00:00', '2023-01-15 15:00:00', 500.00, 'boarding', 1, 2),
    ('British Airways', 2, 3, '2023-02-20', '2023-02-20 10:00:00', '2023-02-20 13:00:00', 600.00, 'inair', 2, 1),
    ('Air France', 3, 3, '2023-03-25', '2023-03-25 08:00:00', '2023-03-25 11:00:00', 700.00, 'landed', 1, 1);
    
INSERT INTO flights (airline, departureairport, arrivalairport, scheduleddeparturetime, actualdeparturetime, arrivaltime, ticketprice, status, departureterminal, arrivalterminal) VALUES 
    ('American Airlines', 1, 3, '2023-04-10', NULL, NULL, 550.00, 'scheduled', 1, 1),
    ('Lufthansa', 2, 1, '2023-04-15', NULL, NULL, 620.00, 'boarding', 2, 2),
    ('Japan Airlines', 3, 2, '2023-04-20', NULL, NULL, 720.00, 'inair', 1, 2),
    ('United Airlines', 1, 2, '2023-04-25', NULL, NULL, 500.00, 'landed', 3, 1),
    ('Emirates', 2, 3, '2023-04-30', NULL, NULL, 800.00, 'scheduled', 1, 1),
    ('Qatar Airways', 3, 1, '2023-05-05', NULL, NULL, 650.00, 'boarding', 2, 3),
    ('Southwest Airlines', 1, 3, '2023-05-10', NULL, NULL, 450.00, 'inair', 1, 2);
SELECT * FROM flights;
INSERT INTO seats (flight_id, seat_number, status, class) VALUES 
    (1, 'A1', 'free', 'Economy'),
    (1, 'A2', 'free', 'Business'),
	(1, 'D1', 'free', 'Economy'),
    (1, 'D2', 'free', 'Economy'),
    (1, 'E1', 'free', 'Business'),
    (1, 'E2', 'free', 'Business'),
    (1, 'F1', 'free', 'Business'),
    (1, 'F2', 'free', 'First'),
    (1, 'F3', 'free', 'First'),
    (1, 'G1', 'free', 'Economy'),
    (1, 'G2', 'free', 'Business'),
    (1, 'G3', 'free', 'First'),
	(2, 'D1', 'free', 'Economy'),
    (2, 'D2', 'free', 'Economy'),
    (2, 'D3', 'free', 'Economy'),
    (2, 'E1', 'free', 'Business'),
    (2, 'E2', 'free', 'Business'),
    (2, 'F1', 'free', 'First'),
    (2, 'F2', 'free', 'First'),
    (2, 'F3', 'free', 'First'),
    (2, 'G1', 'free', 'Economy'),
    (2, 'G2', 'free', 'Business'),
    (2, 'G3', 'free', 'First'),
    (2, 'B1', 'free', 'First'),
    (2, 'B2', 'free', 'Business' ),
    (3, 'C1', 'free', 'Economy'),
    (3, 'C2', 'free', 'Economy'),
	(3, 'D1', 'free', 'Economy'),
    (3, 'D2', 'free', 'Economy'),
    (3, 'E1', 'free', 'Business'),
    (3, 'E2', 'free', 'Business'),
    (3, 'F1', 'free', 'Business'),
    (3, 'F2', 'free', 'First'),
    (3, 'F3', 'free', 'First'),
    (3, 'G1', 'free', 'Economy'),
    (3, 'G2', 'free', 'Business'),
    (3, 'G3', 'free', 'First'),
	(4, 'A1', 'free', 'Economy'),
    (4, 'A2', 'free', 'Business'),
    (4, 'B1', 'free', 'First'),
    (4, 'B2', 'free', 'Business'),
    (4, 'C1', 'free', 'Economy'),
    (4, 'C2', 'free', 'Economy'),
    (5, 'A1', 'free', 'Economy'),
    (5, 'A2', 'free', 'Business'),
    (5, 'A3', 'free', 'Business'),
    (5, 'B1', 'free', 'First'),
    (5, 'B2', 'free', 'First'),
    (5, 'B3', 'free', 'Business'),
	(6, 'A1', 'free', 'Economy'),
    (6, 'A2', 'free', 'Business'),
    (6, 'A3', 'free', 'Business'),
    (6, 'B1', 'free', 'First'),
    (6, 'B2', 'free', 'First'),
    (6, 'B3', 'free', 'Business'),
    (6, 'C1', 'free', 'Economy'),
    (6, 'C2', 'free', 'Economy'),
    (7, 'A1', 'free', 'Economy'),
    (7, 'A2', 'free', 'Business'),
    (7, 'B1', 'free', 'First'),
    (7, 'B2', 'free', 'Business'),
    (7, 'C1', 'free', 'Economy'),
    (7, 'C2', 'free', 'Economy'),
    (8, 'A1', 'free', 'Economy'),
    (8, 'A2', 'free', 'Business'),
    (8, 'B1', 'free', 'First'),
    (8, 'B2', 'free', 'Business'),
    (8, 'C1', 'free', 'Economy'),
    (8, 'C2', 'free', 'Economy'),
    (9, 'A1', 'free', 'Economy'),
    (9, 'A2', 'free', 'Business'),
    (9, 'B1', 'free', 'First'),
    (9, 'B2', 'free', 'First'),
    (9, 'B3', 'free', 'Business'),
    (9, 'C1', 'free', 'Economy'),
    (9, 'C2', 'free', 'Economy'),
    (10, 'A1', 'free', 'Economy'),
    (10, 'A2', 'free', 'Business'),
    (10, 'B1', 'free', 'First'),
    (10, 'B2', 'free', 'First'),
    (10, 'B3', 'free', 'Business'),
    (10, 'C1', 'free', 'Economy'),
    (10, 'C2', 'free', 'Economy');

    -- Insert new scheduled flights
INSERT INTO flights (airline, departureairport, arrivalairport, scheduleddeparturetime, ticketprice, status, departureterminal, arrivalterminal)
VALUES 
    ('American Airlines', 1, 3, '2023-06-01 09:00:00', 550.00, 'scheduled', 1, 1),
    ('Lufthansa', 2, 1, '2023-06-05 11:30:00', 620.00, 'scheduled', 2, 2),
    ('Japan Airlines', 3, 2, '2023-06-10 14:00:00', 720.00, 'scheduled', 1, 2),
    ('Emirates', 2, 3, '2023-06-15 16:30:00', 800.00, 'scheduled', 1, 1),
    ('Qatar Airways', 3, 1, '2023-06-20 18:00:00', 650.00, 'scheduled', 2, 3),
    ('Southwest Airlines', 1, 3, '2023-06-25 20:30:00', 450.00, 'scheduled', 1, 2);

-- Assign seats for the new scheduled flights
INSERT INTO seats (flight_id, seat_number, status, class)
VALUES 
    (11, 'A1', 'free', 'Economy'),
    (11, 'A2', 'free', 'Business'),
    (11, 'B1', 'free', 'First'),
    (11, 'B2', 'free', 'Business'),
    (11, 'C1', 'free', 'Economy'),
    (11, 'C2', 'free', 'Economy'),
    (12, 'A1', 'free', 'Economy'),
    (12, 'A2', 'free', 'Business'),
    (12, 'B1', 'free', 'First'),
    (12, 'B2', 'free', 'Business'),
    (12, 'C1', 'free', 'Economy'),
    (12, 'C2', 'free', 'Economy'),
    (13, 'A1', 'free', 'Economy'),
    (13, 'A2', 'free', 'Business'),
    (13, 'B1', 'free', 'First'),
    (13, 'B2', 'free', 'Business'),
    (13, 'C1', 'free', 'Economy'),
    (13, 'C2', 'free', 'Economy'),
    (14, 'A1', 'free', 'Economy'),
    (14, 'A2', 'free', 'Business'),
    (14, 'B1', 'free', 'First'),
    (14, 'B2', 'free', 'Business'),
    (14, 'C1', 'free', 'Economy'),
    (14, 'C2', 'free', 'Economy'),
    (15, 'A1', 'free', 'Economy'),
    (15, 'A2', 'free', 'Business'),
    (15, 'B1', 'free', 'First'),
    (15, 'B2', 'free', 'Business'),
    (15, 'C1', 'free', 'Economy'),
    (15, 'C2', 'free', 'Economy');


-- Insert values into Customers table
INSERT INTO customers (
    customerid, 
    completename_first, 
    completename_last, 
    completename_middle, 
    phone, 
    city_id, 
    postalcode_id, 
    dateofbirth, 
    sex, 
    specialneeds)
VALUES 
    (1001, 'John', 'Smith', 'A.', 12345678901, 1, 1, '1980-01-15', 'MALE', 'N'),
    (1002, 'Alice', 'Johnson', 'B.', 98765432101, 2, 2, '1992-05-20', 'FEMALE', 'Y'),
    (1003, 'Bob', 'Williams', 'C.', 55555555555, 3, 3, '1985-08-10', 'MALE', 'N'),
    (1004, 'Emily', 'Davis', 'D.', 44444444444, 4, 4, '1990-11-25', 'FEMALE', 'N'),
    (1005, 'Michael', 'Brown', 'E.', 66666666666, 5, 5, '1982-03-30', 'MALE', 'Y'),
    (1006, 'Sophia', 'Jones', 'F.', 33333333333, 6, 6, '1995-07-12', 'FEMALE', 'N'),
	(1007, 'Jennifer', 'Lee', 'G.', 77777777777, 7, 7, '1987-06-18', 'FEMALE', 'N'),
    (1008, 'Daniel', 'Miller', 'H.', 88888888888, 8, 8, '1978-09-23', 'MALE', 'Y'),
    (1009, 'Olivia', 'Garcia', 'I.', 99999999999, 9, 9, '1993-02-14', 'FEMALE', 'N'),
    (1010, 'Ethan', 'Clark', 'J.', 10101010101, 10, 10, '1980-12-05', 'MALE', 'Y');

-- Insert 5 more records into the "Bookings" table
INSERT INTO Bookings ( CustomerID, FlightID, SeatNumber, BookingDate, BookingStatus, CHBStatus, bags) VALUES
    ( 1003, 1, 'A1', '2023-03-27', 'Pending', 'Not checked-in', 0),
    (1004, 2, 'D1', '2023-03-28', 'Confirmed', 'Checked-in', 3),
    ( 1005, 3, 'C1', '2023-03-29', 'Pending', 'Not checked-in', 0),
    ( 1003, 4, 'A1', '2023-03-27', 'Pending', 'Not checked-in', 0),
    ( 1004, 5, 'A1', '2023-03-28', 'Confirmed', 'Checked-in', 3),
    ( 1005, 6, 'A1', '2023-03-29', 'Pending', 'Not checked-in', 0),
    ( 1006, 7, 'A2', '2023-04-04', 'Pending', 'Not checked-in', 0),
    ( 1007, 8, 'C2', '2023-04-05', 'Confirmed', 'Checked-in', 2),
    (1008, 1, 'D2', '2023-04-06', 'Pending', 'Not checked-in', 0),
    ( 1009, 5, 'A2', '2023-04-06', 'Confirmed', 'Not checked-in', 0),
    ( 1010, 1, 'E1', '2023-04-06', 'Confirmed', 'Not checked-in', 0),
    ( 1006, 5, 'B1', '2023-04-06', 'Confirmed', 'Not checked-in', 0),
    ( 1007, 5, 'B2', '2023-04-06', 'Confirmed', 'Not checked-in', 0),
    ( 1008, 2, 'F1', '2023-04-07', 'Confirmed', 'Not checked-in', 1),
    ( 1002, 5, 'A3', '2023-04-06', 'Confirmed', 'Not checked-in', 0),
    ( 1004, 1, 'G1', '2023-04-06', 'Confirmed', 'Not checked-in', 0);



-- Insert data into airlinestaffrecords table\
INSERT INTO airlinestaffrecords (
    staffid, 
    firstname, 
    lastname, 
    middlename, 
    contactnumber, 
    dateofbirth, 
    sex, 
    postalcode_id, 
    job, 
    salary, 
    performance, 
    emrgencycontactperson, 
    emrgencyphone, 
    flightid)
VALUES 
    (1, 'John', 'Doe', 'Moo', 22222222222, '1985-05-15', 'MALE', 1, 'Pilot', 80000.00, 'EXCELLENT', 'Jane Doe', 09564768006, 1),
    (2, 'Alice', 'Smith', 'Cat', 99999999999, '1990-12-10', 'FEMALE', 2, 'Flight Attendant', 50000.00, 'GREAT', 'Bob Smith', 09564768006, 2),
    (3, 'Charlie', 'Brown', 'Luke', 88888888888, '1988-08-22', 'MALE', 3, 'Mechanic', 60000.00, 'GOOD', 'Lucy Brown', 999999999999, 3),
    (4, 'Angel', 'Fenton', 'Marianne', 16284849234, '2004-1-23', 'MALE', 3, 'Mechanic', 111232.00, 'GREAT', 'Kimmy Sanz', 333333333333, 3),
    (5, 'Jona', 'Tarriella', 'Ang', 12394237432, '2003-08-21', 'FEMALE', 3, 'Pilot', 133223.00, 'GOOD', 'Luisa Escalada', 09564768006, 4),
    (6, 'Stephanie', 'Reyes', 'Schrieber', 44444444444, '2004-11-21', 'FEMALE', 3, 'Flight Attendant', 212132.00, 'EXCELLENT', 'Jane Brown', 09209784878, 4),
    (7, 'Kyle', 'Fortuna', 'Delosantos', 1110987654321, '2001-09-18', 'MALE', 3, 'Mechanic', 1232.00, 'GOOD', 'Soobin Choi', 44444444444, 5),
    (8, 'Marc', 'San Pedro', 'Pabilobia', 123456789, '2004-02-11', 'FEMALE', 3, 'Flight Attendant', 12323.00, 'GOOD', 'John Fugoso', 11111111111, 7),
    (9, 'Luis', 'Anton', 'Vale', 33333333333, '2004-03-11', 'MALE', 3, 'Mechanic', 4545.00, 'GOOD', 'Kai Huening', 77777777777, 7),
    (10, 'Jane', 'Brown', 'Edriv', 11111111111, '2004-08-17', 'FEMALE', 3, 'Mechanic', 3232.00, 'GREAT', 'Lucy Sarreal', 222222222222, 7);

-- Insert data into sales table
INSERT INTO sales (saleid, customerid, flightid, transactiondate, transactionmonth, amountpayed, total, method, status, ticketsbooked) VALUES
						(1, 1003, 1, '2023-04-01', 'April', 400.00, 500.00, 'CreditCard', 'Pending', 1),
						(2, 1004, 2, '2023-04-02', 'April', 450.00, 450.00, 'Cash', 'Completed', 1),
						(3, 1005, 3, '2023-04-03', 'April', 500.00, 700.00, 'DebitCard', 'Pending', 1);